package br.com.b3.batch.geraoperacoeseventovcp.service;
import java.util.Arrays;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import br.com.b3.batch.geraoperacoeseventovcp.model.TipoOperObjetoServ;
import br.com.b3.batch.geraoperacoeseventovcp.repository.TipoOperacaoObjetoServicoRespoitory;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.*;

@Service("carregaTiposService")
public class CarregaTiposService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CarregaTiposService.class);
	
	//TIPO_OPERACAO											TIPOS DE EVENTO 
	//	9	VENCIMENTO SEM FINANCEIRO				- 		85 	VENCIMENTO (RESGATE) 				--NAO INCLUIDO
	//	12	RESGATE 								- 		85 	VENCIMENTO (RESGATE)
	//	60	PAGAMENTO DE JUROS						- 		83 	PAGAMENTO DE JUROS
	//	65	INCORPORACAO DE JUROS					- 		89 	INCORPORACAO DE JUROS
	//	69	PAGAMENTO DE RENDIMENTOS 				- 		90 	PAGAMENTO DE RENDIMENTO
	//	74	AMORTIZACAO PROGRAMADA 					- 		84 	AMORTIZACAO
	//  779 ANTECIPACAO DE PARCELA					- 		209 ANTECIPACAO DE PARCELA				ENTENDER A REGRA P/ ESCOLHA DE MODALIDADE	
	//  874 AMORTIZACAO EXTRAORDINARIA				-		97	AMORTIZACAO EXTRAORDINARIA
	//	878	PAGAMENTO PARCELA						-		157	PAGAMENTO DE PARCELA 
	//	960	PAGAMENTO DE JUROS SEM FINANCEIRO		- 		83 	PAGAMENTO DE JUROS     				--NAO INCLUIDO 
	//	974	AMORTIZACAO PROGRAMADA SEM FINANCEIRO	- 		84 	AMORTIZACAO							--NAO INCLUIDO
	//	873 PGTO. JUROS SOBRE AMORTIZACAO EXTRAORDINARIA  - ??  ?? 									--NAO INCLUIDO
	private static final Integer[] CODIGOS_TIPO_OPERACAO_EVENTOS = {12,60,65,69,74,779,874,878};

	private Map<Integer, Integer> mapaTipoOpersParaTipoEventos;
	private void combinarTipoOperacaoComTipoEvento() {
		mapaTipoOpersParaTipoEventos = new HashMap<Integer, Integer>();
		mapaTipoOpersParaTipoEventos.put(12,85);
		mapaTipoOpersParaTipoEventos.put(60,83);
		mapaTipoOpersParaTipoEventos.put(65,89);
		mapaTipoOpersParaTipoEventos.put(69,90);
		mapaTipoOpersParaTipoEventos.put(74,84);
		mapaTipoOpersParaTipoEventos.put(779,209);
		mapaTipoOpersParaTipoEventos.put(874,97);
		mapaTipoOpersParaTipoEventos.put(878,157);
	}
	
	@Autowired
	private TipoOperacaoObjetoServicoRespoitory tipoOperacaoObjetoServicoRespoitory;
	
	//retorno<Integer numTipoEventoLegado, TipoOperObjetoServ>
	@Cacheable(key = "'allTipos'", value = "allTiposOperObjServ")
	public Map<Integer, TipoOperObjetoServ> carregarTiposOperObjServPorIdObjServECodTipoOper() {
		
		combinarTipoOperacaoComTipoEvento();
		
		Map<Integer, TipoOperObjetoServ> retorno = new HashMap<Integer, TipoOperObjetoServ>();
		
		List<TipoOperObjetoServ> tipos = tipoOperacaoObjetoServicoRespoitory.findAllByNumIdObjetoServicoAndCodTipoOperacaoIn(OBJETO_SERVICO_CCB, Collections.unmodifiableList(Arrays.asList(CODIGOS_TIPO_OPERACAO_EVENTOS)));

		for (TipoOperObjetoServ tipoOperObjetoServ : tipos) {
			retorno.put(mapaTipoOpersParaTipoEventos.get(tipoOperObjetoServ.getTipoOperacao().getCodTipoOperacao()), tipoOperObjetoServ);
		}
		
		return retorno;
	}
	
	@Cacheable(key = "T(java.lang.String).valueOf(#numIdObjetoServico).concat('-').concat(#codigoTipoOperacao)", value = "numIdTipoOperObjetoServ", unless="#result == null" )
	public Integer obterTiposOperObjServPorIdObjServECodTipoOperacao(Integer numIdObjetoServico, Integer codigoTipoOperacao) {
		
		TipoOperObjetoServ tipoOperObjetoServ = tipoOperacaoObjetoServicoRespoitory.findByNumIdObjetoServicoAndCodTipoOperacao(numIdObjetoServico, codigoTipoOperacao);
		
		Integer retorno = null;
		if(tipoOperObjetoServ != null && tipoOperObjetoServ.getNumIdTipoOperObjetoServ() != null) {
			retorno = tipoOperObjetoServ.getNumIdTipoOperObjetoServ();
		}
		
		return retorno;
	}
}