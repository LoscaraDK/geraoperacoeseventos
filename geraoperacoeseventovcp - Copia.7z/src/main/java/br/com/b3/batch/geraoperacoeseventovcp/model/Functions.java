package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the TIPO_OPERACAO database table.
 * 
 */
@Entity
@Table(name="DUAL")
public class Functions implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="ID")
	private long numIdTipoOperacao;

	public long getNumIdTipoOperacao() {
		return numIdTipoOperacao;
	}

	public void setNumIdTipoOperacao(long numIdTipoOperacao) {
		this.numIdTipoOperacao = numIdTipoOperacao;
	}


}