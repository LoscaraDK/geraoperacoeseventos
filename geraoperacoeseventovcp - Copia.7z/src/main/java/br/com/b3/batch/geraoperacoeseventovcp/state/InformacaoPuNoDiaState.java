package br.com.b3.batch.geraoperacoeseventovcp.state;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_AGUARDANDO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_PROCESSADO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_BT;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_STR;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_SEM;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.PENDENTE_LIQUIDACAO_FINANCEIRA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.PEND_ATU_VALOR;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InformacaoPuNoDiaState implements OperacaoState{
	private Integer situacaoOperacao;
	private String codCtlProcessamento;
	private static final Logger LOGGER = LoggerFactory.getLogger(InformacaoPuNoDiaState.class);
	private static InformacaoPuNoDiaState instance = new InformacaoPuNoDiaState();
	
	private InformacaoPuNoDiaState() {}
	
	public static InformacaoPuNoDiaState instance() {
		return instance;
	}
	
	private static final Map<Integer, Integer> map = new HashMap<Integer, Integer>();
	static {
		map.put(MODALIDADE_BRUTA_BT, PEND_ATU_VALOR);
		map.put(MODALIDADE_BRUTA_STR, PEND_ATU_VALOR);
		map.put(MODALIDADE_CETIP, PEND_ATU_VALOR);
		map.put(MODALIDADE_SEM, PEND_ATU_VALOR);
	}
	
	@Override
	public Integer getSituacaoOperacao() {
		return this.situacaoOperacao;
	}
	
	@Override
	public String getCodCtlProcessamento() {
		return this.codCtlProcessamento;
	}
	
	private void setSituacaoOperacao(Integer situacaoOperacao) {
		this.situacaoOperacao = situacaoOperacao;
		
		setCodCtlProcessamento();
	}
	
	private void setCodCtlProcessamento() {
		this.codCtlProcessamento = COD_CTL_PROCESSAMENTO_PROCESSADO;
		if(PENDENTE_LIQUIDACAO_FINANCEIRA.equals(situacaoOperacao)) {
			this.codCtlProcessamento = COD_CTL_PROCESSAMENTO_AGUARDANDO;
		}
	}
	
	@Override
	public void updateState(SituacaoOperacaoContext context) {
		setSituacaoOperacao(map.get(context.getParameters().getModalidade()));
		
		LOGGER.debug(this + " -> " + context.getCurrent().getSituacaoOperacao() 
				+ " na modalide " + context.getParameters().getModalidade() + " com codCtlProcessamento " + context.getCurrent().getCodCtlProcessamento());
	}
}
