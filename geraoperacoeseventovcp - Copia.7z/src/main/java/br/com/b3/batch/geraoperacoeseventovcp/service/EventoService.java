package br.com.b3.batch.geraoperacoeseventovcp.service;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.ESTADO_EVENTO_ATU_RETIRADO_EVENTO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import br.com.b3.batch.geraoperacoeseventovcp.repository.CcbVcpD1AmortResgRepository;
import br.com.b3.batch.geraoperacoeseventovcp.repository.CcbVcpD1JurosRendRepository;
import br.com.b3.batch.geraoperacoeseventovcp.repository.CcbVcpD1OutroRepository;
import br.com.b3.batch.geraoperacoeseventovcp.repository.CcbVcpVenAmortResgRepository;
import br.com.b3.batch.geraoperacoeseventovcp.repository.CcbVcpVenJurosRendRepository;
import br.com.b3.batch.geraoperacoeseventovcp.repository.CcbVcpVenOutroRepository;
import br.com.b3.batch.geraoperacoeseventovcp.repository.VctpEventosRetiradosRepository;

@Service("eventoService")
@Transactional("nomeTransactionManager")
public class EventoService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(EventoService.class);
	
	@Autowired
	private CcbVcpD1AmortResgRepository ccbVcpD1AmortResgRespository;
	
	@Autowired
	private CcbVcpD1JurosRendRepository ccbVcpD1JurosRendRepository;
	
	@Autowired
	private CcbVcpD1OutroRepository ccbVcpD1OutroRepository;
	
	@Autowired
	private CcbVcpVenAmortResgRepository ccbVcpVenAmortResgRepository;
	
	@Autowired
	private CcbVcpVenJurosRendRepository ccbVcpVenJurosRendRepository;
	
	@Autowired
	private CcbVcpVenOutroRepository ccbVcpVenOutroRepository;
	
	@Autowired
	private VctpEventosRetiradosRepository eventosRetirados;

	public Integer countEventosCcbVcpD1AmortResg() {
		return (int) ccbVcpD1AmortResgRespository.count();
	}
	
	public Integer countEventosCcbVcpD1JurosRend() {
		return (int) ccbVcpD1JurosRendRepository.count();
	}
	
	public Integer countEventosCcbVcpD1Outro() {
		return (int) ccbVcpD1OutroRepository.count();
	}
	
	public Integer countEventosCcbVcpVenAmortResg() {
		return (int) ccbVcpVenAmortResgRepository.count();
	}
	
	public Integer countEventosCcbVcpVenJurosRend() {
		return (int) ccbVcpVenJurosRendRepository.count();
	}
	
	public Integer countEventosCcbVcpVenOutro() {
		return (int) ccbVcpVenOutroRepository.count();
	}
	
	public boolean existeEventosRetirados(Long numEvento, Long numContaParticipanteP2, Integer numIdEstadoEventoAlvo) {
		
		boolean retorno = false;
		
		if(ESTADO_EVENTO_ATU_RETIRADO_EVENTO.equals(numIdEstadoEventoAlvo)) {
			retorno = eventosRetirados.getCountEventosRetirados(numEvento, numContaParticipanteP2) > 0;
		}
		
		return retorno;
	}
}