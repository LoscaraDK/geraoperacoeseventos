package br.com.b3.batch.geraoperacoeseventovcp.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.b3.batch.geraoperacoeseventovcp.model.TipoOperObjetoServ;

public interface TipoOperacaoObjetoServicoRespoitory extends JpaRepository<TipoOperObjetoServ, Long> {
	
	@Query("select t from TipoOperObjetoServ t where t.numIdObjetoServico =:numIdObjetoServico and t.tipoOperacao.codTipoOperacao in (:tipos)")
	List<TipoOperObjetoServ> findAllByNumIdObjetoServicoAndCodTipoOperacaoIn(@Param("numIdObjetoServico") Integer numIdObjetoServico,@Param("tipos") List<Integer> tipos);
	
	@Query("select t from TipoOperObjetoServ t where t.numIdObjetoServico =:numIdObjetoServico and t.tipoOperacao.codTipoOperacao =:codigoTipoOperacao")
	TipoOperObjetoServ findByNumIdObjetoServicoAndCodTipoOperacao(@Param("numIdObjetoServico") Integer numIdObjetoServico,@Param("codigoTipoOperacao") Integer codigoTipoOperacao);
}
