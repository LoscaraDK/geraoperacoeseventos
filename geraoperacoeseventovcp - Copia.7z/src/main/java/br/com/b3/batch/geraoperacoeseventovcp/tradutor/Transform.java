package br.com.b3.batch.geraoperacoeseventovcp.tradutor;

import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.OBJETO_SERVICO_CCB;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.b3.batch.geraoperacoeseventovcp.config.BatchJob;
import br.com.b3.batch.geraoperacoeseventovcp.mapper.SelecionaMapContext;
import br.com.b3.batch.geraoperacoeseventovcp.modalidade.ModalidadeContext;
import br.com.b3.batch.geraoperacoeseventovcp.modalidade.ModalidadeParameters;
import br.com.b3.batch.geraoperacoeseventovcp.model.BaseCcbVcp;
import br.com.b3.batch.geraoperacoeseventovcp.model.ContaParticipante;
import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;
import br.com.b3.batch.geraoperacoeseventovcp.service.CarregaTiposService;
import br.com.b3.batch.geraoperacoeseventovcp.service.ContasService;
import br.com.b3.batch.geraoperacoeseventovcp.service.DadosLiquidantesService;
import br.com.b3.batch.geraoperacoeseventovcp.service.EventoService;
import br.com.b3.batch.geraoperacoeseventovcp.service.UtilsService;
import br.com.b3.batch.geraoperacoeseventovcp.state.ParametersVO;
import br.com.b3.batch.geraoperacoeseventovcp.state.SituacaoOperacaoContext;

@Component
public class Transform {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(Transform.class);
	
	@Autowired
	private CarregaTiposService carregaTipoService;
	
	@Autowired
	private UtilsService utilsService;
	
	@Autowired
	private DadosLiquidantesService dadosLiquidante;
	
	@Autowired
	private ContasService contasService;
	
	@Autowired
	private EventoService eventoService;
	
	public Operacao process(BaseCcbVcp evento) throws Exception {
		
		ModalidadeParameters modalidadeParameters = constroiModalidadeParameters(evento);
		ModalidadeContext modalidadeContext = ModalidadeContext.instance(modalidadeParameters).execute();
		
		ParametersVO sitOpersParameters = constroiParameters(evento, modalidadeContext);
		SituacaoOperacaoContext ctx = new SituacaoOperacaoContext(null, sitOpersParameters).next();
		
		Integer numIdFormaPagamento = evento.getTitulo().getNumIdFormaPagamento();
		Integer numTipoEventoLegado = evento.getNumTipoEventoLegado();
		SelecionaMapContext codigosTipoOperacaoCtx = new SelecionaMapContext(numTipoEventoLegado, numIdFormaPagamento); 
		Integer codigoTipoOperacao = codigosTipoOperacaoCtx.selecionaMap().getCurrentMap().getCodigoTipoOperacao();
		Integer tipoOperObjetoServ = carregaTipoService.obterTiposOperObjServPorIdObjServECodTipoOperacao(OBJETO_SERVICO_CCB, codigoTipoOperacao);
		
		Operacao operacao = new Operacao();
		operacao.setCodOperacao(utilsService.geraCodigoOperacao());
		operacao.setNumIF(evento.getTitulo().getNumIf());
		operacao.setQtdOperacao(evento.getQtd().longValue());
		operacao.setCodCtlProcessamento(ctx.getCurrent().getCodCtlProcessamento()); 
		operacao.setCodSituacaoOperacao(ctx.getCurrent().getSituacaoOperacao());  
		operacao.setNumContaParticipanteP1(modalidadeParameters.getNumContaP1()); 
		operacao.setNumContaParticipanteP2(evento.getNumContaDetentor());
		operacao.setIndLancadoP1("S");
		operacao.setIndLancadoP2("N");
		operacao.setValPrecoUnitario(evento.getValPuEvento());
		operacao.setValFinanceiro(modalidadeParameters.getValorFinanceiro());
		operacao.setEvento(evento.getEvento());
		operacao.setNumIdModalidadeLiquidacao(modalidadeContext.getStrategy().getModalidadeDetalhada()); 
		operacao.setDatOperacao(evento.getDatOcorrenciaEvento());
		operacao.setDatFinanceiro(evento.getDatLiquidacao());
		operacao.setNumIdTipoOperObjetoServ(tipoOperObjetoServ);
		operacao.setNumIdEntidadeP1(modalidadeParameters.getNumEntidadeLiquidanteP1());
		operacao.setNumIdEntidadeP2(modalidadeParameters.getNumEntidadeLiquidanteP2());
		operacao.setCodTipoDebitoP1(2);
		operacao.setCodTipoDebitoP2(2);
		operacao.setDatInclusao(utilsService.getDataHoje());
		operacao.setHistorico("jobSGeraOpersVCP");
		
		return operacao;
	}
	
	private Long selecionaContaP1(BaseCcbVcp evento) {
		Long numContaP1 = evento.getNumContaEmissor();
		if(evento.getNumContaAgentePagamento() != null && evento.getNumContaAgentePagamento() > 0) {
			numContaP1 = evento.getNumContaAgentePagamento();
		}
		
		return numContaP1;
	}
	
	private ParametersVO constroiParameters(BaseCcbVcp evento, ModalidadeContext modalidadeContext) {
		boolean eRetiradoPorSolicitacao = eventoService.existeEventosRetirados(evento.getEvento().getNumEvento(), evento.getNumContaDetentor(), evento.getNumIdEstadoEvento());
		
		ParametersVO vo = new ParametersVO.ParametersBuilder()
				.addContaP1Inativa(contasService.eContaInativa(selecionaContaP1(evento)))
				.addContaP2Inativa(contasService.eContaInativa(evento.getNumContaDetentor()))
				.addEstadoEvento(evento.getNumIdEstadoEvento())
				.addModalidade(modalidadeContext.getStrategy().getModalidadeDetalhada())
				.addNumTipoEventoLegado(evento.getNumTipoEventoLegado())
				.addRetiradoPorSolicitacao(eRetiradoPorSolicitacao)
				.build();
		
		return vo;
	}
	
	private ModalidadeParameters constroiModalidadeParameters(BaseCcbVcp evento) {

		Long numContaP1 = selecionaContaP1(evento);
		
		Integer numIdFormaPagamento = evento.getTitulo().getNumIdFormaPagamento();
		
		Long numIdLiquidanteP1 = dadosLiquidante.carregarNumIdLiquidante(numContaP1);
		Long numIdLiquidanteP2 = dadosLiquidante.carregarNumIdLiquidante(evento.getNumContaDetentor()); 
		
		ContaParticipante contaParticipanteP1 = contasService.obterContaParticipantePorId(numContaP1);
		ContaParticipante contaParticipanteP2 = contasService.obterContaParticipantePorId(evento.getNumContaDetentor());
		
		BigDecimal valFinanceiro = null;
		if ((evento.getValPuEvento() != null && evento.getValPuEvento().compareTo(BigDecimal.ZERO) > 0)
				&& (evento.getQtd() != null && evento.getQtd().compareTo(BigDecimal.ZERO) > 0)) {
			valFinanceiro = evento.getValPuEvento().multiply(evento.getQtd());
		}
		
		ModalidadeParameters modalidadeParameters = new ModalidadeParameters.ModalidadeParametersBuilder()
													.addNumContaP1(numContaP1)
													.addNumContaP2(evento.getNumContaDetentor())
													.addCodContaP1(contaParticipanteP1.getCodContaParticipante())
													.addCodContaP2(contaParticipanteP2.getCodContaParticipante())
													.addNumEntidadeContaP1(contaParticipanteP1.getNumIdEntidade())
													.addNumEntidadeContaP2(contaParticipanteP2.getNumIdEntidade())
													.addNumEntidadeLiquidanteP1(numIdLiquidanteP1)
													.addNumEntidadeLiquidanteP2(numIdLiquidanteP2)
													.addEstadoEvento(evento.getNumIdEstadoEvento())
													.addIndConfirmacaoPagamento(evento.getIndConfirmacaoPagamento())
													.addIndEventosCursadosCetip(evento.getTitulo().getIndEventosCursadosCetip())
													.addIndVencidoInadimplido(evento.getTitulo().getIndVencidoInadimplido())
													.addCodCoobrigacao(evento.getCodCoobrigacao())
													.addNumTipoEventoLegado(evento.getNumTipoEventoLegado())
													.addPercentualPagamento(evento.getValPercentualPagamento())
													.addValorFinanceiro(valFinanceiro)
													.addNumIdFormaPagamento(numIdFormaPagamento)
													.build();
		
		return modalidadeParameters;
	}
	
	
}
