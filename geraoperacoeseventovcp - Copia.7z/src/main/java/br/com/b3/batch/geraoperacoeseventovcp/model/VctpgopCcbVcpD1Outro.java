package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the VCTPGOP_CCB_VCP_D1_OUTROS database table.
 * 
 */
@Entity
@Table(name="VCTPGOP_CCB_VCP_D1_OUTROS", schema="CETIP")
@NamedQuery(name="VctpgopCcbVcpD1Outro.findAll", query="SELECT v FROM VctpgopCcbVcpD1Outro v")
public class VctpgopCcbVcpD1Outro extends BaseCcbVcp implements Serializable {
}