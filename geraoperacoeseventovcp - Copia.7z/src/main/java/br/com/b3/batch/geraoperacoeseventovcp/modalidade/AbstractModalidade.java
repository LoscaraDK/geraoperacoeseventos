package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_BILATERAL;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_BRUTA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_SEM;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BILATERAL_BT;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BILATERAL_STR;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_BT;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_STR;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TP_CONTA_BROKER;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TP_CONTA_CLIENTE_1;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TP_CONTA_CLIENTE_2;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TP_CONTA_EMISSORA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TP_CONTA_GARANTIA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TP_CONTA_PROPRIA;

import br.com.b3.batch.geraoperacoeseventovcp.tradutor.TradutorModalidade;

public abstract class AbstractModalidade implements ModalidadeStrategy {
	protected Integer ajustaGrupoModalidade(ModalidadeParameters parameters, Integer grpModalidadeAjustada) {

		Integer retorno = grpModalidadeAjustada;
		if (grpModalidadeAjustada.equals(GRP_MODALIDADE_BRUTA) || grpModalidadeAjustada.equals(GRP_MODALIDADE_CETIP)) {
			if (parameters.getNumEntidadeContaP1().equals(parameters.getNumEntidadeContaP2())) {
				if (parameters.getTipoCodContaP2().equals(TP_CONTA_PROPRIA)
						|| parameters.getTipoCodContaP2().equals(TP_CONTA_CLIENTE_1)
						|| parameters.getTipoCodContaP2().equals(TP_CONTA_CLIENTE_2)
						|| parameters.getTipoCodContaP2().equals(TP_CONTA_EMISSORA)
						|| parameters.getTipoCodContaP2().equals(TP_CONTA_GARANTIA)) {
					retorno = GRP_MODALIDADE_SEM;
				}
			}
		}

		return retorno;
	}
	
	protected Integer ajustaModalidadeLiquidacao(ModalidadeParameters parameters, Integer grpModalidadeAjustada) {

		Integer modalidade = null;
		if (GRP_MODALIDADE_BILATERAL.equals(grpModalidadeAjustada)) {
			if (parameters.getNumEntidadeLiquidanteP1().equals(parameters.getNumEntidadeLiquidanteP2())) {
				modalidade = MODALIDADE_BILATERAL_BT;
			} else {
				modalidade = MODALIDADE_BILATERAL_STR;
			}
		} else if (GRP_MODALIDADE_BRUTA.equals(grpModalidadeAjustada)) {
			if (parameters.getNumEntidadeLiquidanteP1().equals(parameters.getNumEntidadeLiquidanteP2())) {
				if (parameters.getTipoCodContaP1().equals(TP_CONTA_BROKER)
						|| parameters.getTipoCodContaP2().equals(TP_CONTA_BROKER)) {

					modalidade = MODALIDADE_BRUTA_STR;
				} else {
					// a modalidade para liquidacao de um evento nunca podera ser BT AUT
					modalidade = MODALIDADE_BRUTA_BT;
				}
			} else {
				modalidade = MODALIDADE_BRUTA_STR;
			}
		} else { // modalidade não tratada, retorna a default
			modalidade = TradutorModalidade.instance().traduzModalidadePadrao(grpModalidadeAjustada); 
		}

		return modalidade;
	}
}
