package br.com.b3.batch.geraoperacoeseventovcp.metrics;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.stereotype.Component;

@Component
@Endpoint(id = "spring.batch.executions")
public class BatchMetricEndpoint {

    @Autowired
    BatchAllJobsMetricContext batchAllJobsMetricContext;

    @ReadOperation
    public Map<String, BatchPerJobMetricContext> features() {
        return batchAllJobsMetricContext.getAll();
    }
}