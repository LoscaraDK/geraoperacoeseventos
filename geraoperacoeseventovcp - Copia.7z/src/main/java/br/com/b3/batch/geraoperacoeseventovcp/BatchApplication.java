package br.com.b3.batch.geraoperacoeseventovcp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.util.StringUtils;

import com.ulisesbocchio.jasyptspringboot.annotation.EnableEncryptableProperties;

@EnableCaching
@SpringBootApplication(exclude = { DataSourceAutoConfiguration.class })
@EnableEncryptableProperties
public class BatchApplication implements CommandLineRunner {
	private static final Logger LOGGER = LoggerFactory.getLogger(BatchApplication.class);	
	
	public static void main(String[] args) {
		LOGGER.info("lista de argumentos no main -> " + StringUtils.arrayToDelimitedString(args, ",") );
		SpringApplication.run(BatchApplication.class, args);
	}
	
	@Autowired
	private JobLauncher launcher;
	
	@Autowired
	@Qualifier(value = "jobSGeraOpersVCP")
	private Job job;

	@Override
	public void run(String... args) throws Exception {
		LOGGER.debug("lista de argumentos no run -> " + StringUtils.arrayToDelimitedString(args, ",") );
		
		Integer counter = 0;
		
		JobParameters params = new JobParametersBuilder()
								.addString("converteEventosEmOperacoes", String.valueOf(System.currentTimeMillis()))
								.addString("executionCount",""+counter++)
								.toJobParameters();
		launcher.run(job, params);
	}
}