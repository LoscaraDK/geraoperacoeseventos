package br.com.b3.batch.geraoperacoeseventovcp.state;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_AGUARDANDO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_PROCESSADO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_BT;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_STR;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_SEM;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.PENDENTE_LIQUIDACAO_FINANCEIRA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.PEND_ATU_VALOR;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.PEND_LANC_PU_EVENTO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TIPO_EVENTO_AMORTIZACAO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TIPO_EVENTO_AMORTIZACAO_EXTRAORDINARIA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.TIPO_EVENTO_PAGAMENTO_RENDIMENTO;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
//TODO: ALTERAR DE ACORDO COM O NOME
public class PuCalculadoSistemaState implements OperacaoState{
	private Integer situacaoOperacao;
	private String codCtlProcessamento;
	private static final Integer EXCECAO_REGRA = 99; 
	private static final Logger LOGGER = LoggerFactory.getLogger(PuCalculadoSistemaState.class);
	private static PuCalculadoSistemaState instance = new PuCalculadoSistemaState();
	
	private PuCalculadoSistemaState() {}
	
	public static PuCalculadoSistemaState instance() {
		return instance;
	}
	
	private static final Map<Integer, Integer> map = new HashMap<Integer, Integer>();
	static {
		
//		BRUTA - 231 (SEMENTE PRA 69, 74 ou 874)
		map.put(MODALIDADE_BRUTA_BT, PEND_ATU_VALOR);
		map.put(MODALIDADE_BRUTA_STR, PEND_ATU_VALOR);
		map.put(MODALIDADE_CETIP, PEND_ATU_VALOR);
		map.put(MODALIDADE_SEM, PEND_ATU_VALOR);
		map.put(EXCECAO_REGRA, PEND_LANC_PU_EVENTO);
	}
	
	@Override
	public Integer getSituacaoOperacao() {
		return this.situacaoOperacao;
	}
	
	@Override
	public String getCodCtlProcessamento() {
		return this.codCtlProcessamento;
	}
	
	private void setSituacaoOperacao(Integer situacaoOperacao) {
		this.situacaoOperacao = situacaoOperacao;
		
		setCodCtlProcessamento();
	}
	
	private void setCodCtlProcessamento() {
		this.codCtlProcessamento = COD_CTL_PROCESSAMENTO_PROCESSADO;
		if(PENDENTE_LIQUIDACAO_FINANCEIRA.equals(situacaoOperacao)) {
			this.codCtlProcessamento = COD_CTL_PROCESSAMENTO_AGUARDANDO;
		}
	}
	
	@Override
	public void updateState(SituacaoOperacaoContext context) {
		if(eExcecaoRegra(context.getParameters().getNumTipoEvento()) && eModaliBruta(context.getParameters().getModalidade())) {
			setSituacaoOperacao(map.get(EXCECAO_REGRA));
		}else {
			setSituacaoOperacao(map.get(context.getParameters().getModalidade()));
		}
		
		
		LOGGER.debug(this + " -> " + context.getCurrent().getSituacaoOperacao() 
				+ " na modalide " + context.getParameters().getModalidade() + " com codCtlProcessamento " + context.getCurrent().getCodCtlProcessamento());
		
	}
	
	private boolean eExcecaoRegra (Integer numTipoEvento) {
		boolean retorno = false;
		
		retorno = TIPO_EVENTO_AMORTIZACAO.equals(numTipoEvento) || 
				  TIPO_EVENTO_AMORTIZACAO_EXTRAORDINARIA.equals(numTipoEvento) ||
				  TIPO_EVENTO_PAGAMENTO_RENDIMENTO.equals(numTipoEvento);
		
		return retorno;
	}
	
	private boolean eModaliBruta (Integer modalidade) {
		return MODALIDADE_BRUTA_BT.equals(modalidade) || MODALIDADE_BRUTA_STR.equals(modalidade);
	}
}
