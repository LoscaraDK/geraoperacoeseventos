package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@MappedSuperclass
public class BaseCcbVcp {
	@Column(name="COD_COOBRIGACAO")
	private String codCoobrigacao;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_LIQUIDACAO")
	private Date datLiquidacao;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_OCORRENCIA_EVENTO")
	private Date datOcorrenciaEvento;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_VENCIMENTO")
	private Date datVencimento;
	
	@Id
	@Column(name="ID_VIEW")
	private Long idView;

	@Column(name="IND_CONFIRMACAO_PAGAMENTO")
	private String indConfirmacaoPagamento;

	@Column(name="NUM_CONTA_AGENTE_PAGAMENTO")
	private Long numContaAgentePagamento;

	@Column(name="NUM_CONTA_DETENTOR")
	private Long numContaDetentor;

	@Column(name="NUM_CONTA_EMISSOR")
	private Long numContaEmissor;

	@ManyToOne
	@JoinColumn(name="NUM_EVENTO")
	private Evento evento;

	@Column(name="NUM_ID_ESTADO_EVENTO")
	private Integer numIdEstadoEvento;

	@ManyToOne
	@JoinColumn(name="NUM_IF")
	private Titulo titulo;

	@Column(name="NUM_IF_PERTENCE")
	private Long numIfPertence;

	@Column(name="NUM_TIPO_EVENTO_LEGADO")
	private Integer numTipoEventoLegado;

	@Column(name="NUM_TIPO_IF")
	private Long numTipoIf;
	
	@Column(name="QTD")
	private BigDecimal qtd;

	@Column(name="VAL_PERC_PGTO")
	private BigDecimal valPercPgto;

	@Column(name="VAL_PERCENTUAL_PAGAMENTO")
	private BigDecimal valPercentualPagamento;

	@Column(name="VAL_PU_EVENTO")
	private BigDecimal valPuEvento;

	@Column(name="VAL_PU_JUROS_AMORTIZACAO")
	private BigDecimal valPuJurosAmortizacao;

	public String getCodCoobrigacao() {
		return this.codCoobrigacao;
	}

	public void setCodCoobrigacao(String codCoobrigacao) {
		this.codCoobrigacao = codCoobrigacao;
	}

	public Date getDatLiquidacao() {
		return this.datLiquidacao;
	}

	public void setDatLiquidacao(Date datLiquidacao) {
		this.datLiquidacao = datLiquidacao;
	}

	public Date getDatOcorrenciaEvento() {
		return this.datOcorrenciaEvento;
	}

	public void setDatOcorrenciaEvento(Date datOcorrenciaEvento) {
		this.datOcorrenciaEvento = datOcorrenciaEvento;
	}

	public Date getDatVencimento() {
		return this.datVencimento;
	}

	public void setDatVencimento(Date datVencimento) {
		this.datVencimento = datVencimento;
	}

	public Long getIdView() {
		return this.idView;
	}

	public void setIdView(Long idView) {
		this.idView = idView;
	}

	public String getIndConfirmacaoPagamento() {
		return this.indConfirmacaoPagamento;
	}

	public void setIndConfirmacaoPagamento(String indConfirmacaoPagamento) {
		this.indConfirmacaoPagamento = indConfirmacaoPagamento;
	}

	public Long getNumContaAgentePagamento() {
		return this.numContaAgentePagamento;
	}

	public void setNumContaAgentePagamento(Long numContaAgentePagamento) {
		this.numContaAgentePagamento = numContaAgentePagamento;
	}

	public Long getNumContaDetentor() {
		return this.numContaDetentor;
	}

	public void setNumContaDetentor(Long numContaDetentor) {
		this.numContaDetentor = numContaDetentor;
	}

	public Long getNumContaEmissor() {
		return this.numContaEmissor;
	}

	public void setNumContaEmissor(Long numContaEmissor) {
		this.numContaEmissor = numContaEmissor;
	}

	public Evento getEvento() {
		return this.evento;
	}

	public void setEvento(Evento evento) {
		this.evento = evento;
	}

	public Integer getNumIdEstadoEvento() {
		return this.numIdEstadoEvento;
	}

	public void setNumIdEstadoEvento(Integer numIdEstadoEvento) {
		this.numIdEstadoEvento = numIdEstadoEvento;
	}

	public Titulo getTitulo() {
		return this.titulo;
	}

	public void setTitulo(Titulo titulo) {
		this.titulo = titulo;
	}

	public Long getNumIfPertence() {
		return this.numIfPertence;
	}

	public void setNumIfPertence(Long numIfPertence) {
		this.numIfPertence = numIfPertence;
	}

	public Integer getNumTipoEventoLegado() {
		return this.numTipoEventoLegado;
	}

	public void setNumTipoEventoLegado(Integer numTipoEventoLegado) {
		this.numTipoEventoLegado = numTipoEventoLegado;
	}

	public Long getNumTipoIf() {
		return this.numTipoIf;
	}

	public void setNumTipoIf(Long numTipoIf) {
		this.numTipoIf = numTipoIf;
	}

	public BigDecimal getQtd() {
		return this.qtd;
	}

	public void setQtd(BigDecimal qtd) {
		this.qtd = qtd;
	}

	public BigDecimal getValPercPgto() {
		return this.valPercPgto;
	}

	public void setValPercPgto(BigDecimal valPercPgto) {
		this.valPercPgto = valPercPgto;
	}

	public BigDecimal getValPercentualPagamento() {
		return this.valPercentualPagamento;
	}

	public void setValPercentualPagamento(BigDecimal valPercentualPagamento) {
		this.valPercentualPagamento = valPercentualPagamento;
	}

	public BigDecimal getValPuEvento() {
		return this.valPuEvento;
	}

	public void setValPuEvento(BigDecimal valPuEvento) {
		this.valPuEvento = valPuEvento;
	}

	public BigDecimal getValPuJurosAmortizacao() {
		return this.valPuJurosAmortizacao;
	}

	public void setValPuJurosAmortizacao(BigDecimal valPuJurosAmortizacao) {
		this.valPuJurosAmortizacao = valPuJurosAmortizacao;
	}

}
