package br.com.b3.batch.geraoperacoeseventovcp.listener;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemWriteListener;

import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;

public class EventoItemWriterListener implements ItemWriteListener<Operacao> {

	private static final Logger LOGGER = LoggerFactory.getLogger(EventoItemWriterListener.class);
	@Override
	public void afterWrite(List<? extends Operacao> operacoes) {
		LOGGER.debug(this + " -> total de geradas -> " + operacoes.size());
	}

	@Override
	public void beforeWrite(List<? extends Operacao> operacoes) {
			LOGGER.debug(this + " -> beforeWrite" );		
	}

	@Override
	public void onWriteError(Exception e, List<? extends Operacao> operacoes) {
		LOGGER.debug("onWriteError");
		e.printStackTrace();	
	}
	
	
}
