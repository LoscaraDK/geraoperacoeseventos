package br.com.b3.batch.geraoperacoeseventovcp.mapper;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.*;
public class SelecionaMapContext {
	private CodigoMap current; 
	private Integer numTipoEventoLegado;
	private Integer numIdFormaPagamento;
	
	public SelecionaMapContext(Integer numTipoEventoLegado, Integer numIdFormaPagamento) {
		
		this.numTipoEventoLegado = numTipoEventoLegado;
		this.numIdFormaPagamento = numIdFormaPagamento;
		
		if(CCB_LIQUIDACAO_FORA_AMBITO_B3.equals(numIdFormaPagamento)) {
			current = CodigosTpOperLiqForaAmbitoMap.instance();
		}else {
			current = CodigosTpOperOutrosMap.instance();
		}
	}

	public Integer getNumTipoEventoLegado() {
		return numTipoEventoLegado;
	}
	public Integer getNumIdFormaPagamento() {
		return numIdFormaPagamento;
	}
	public CodigoMap getCurrentMap() {
		return this.current;
	}
	
	public SelecionaMapContext selecionaMap() {
		current.seleciona(this);
		return this;
	}
	
	public static void main(String[] args) {
		SelecionaMapContext ctx = new SelecionaMapContext(TIPO_EVENTO_AMORTIZACAO, CCB_AMORTIZACAO_SEM_JUROS);
		System.out.println(ctx.selecionaMap().getCurrentMap().getCodigoTipoOperacao());
		
		SelecionaMapContext ctx1 = new SelecionaMapContext(TIPO_EVENTO_AMORTIZACAO, CCB_LIQUIDACAO_FORA_AMBITO_B3);
		System.out.println(ctx1.selecionaMap().getCurrentMap().getCodigoTipoOperacao());
		
	}
}
