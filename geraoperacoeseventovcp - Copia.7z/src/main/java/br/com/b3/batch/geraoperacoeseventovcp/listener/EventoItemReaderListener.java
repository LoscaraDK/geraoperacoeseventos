package br.com.b3.batch.geraoperacoeseventovcp.listener;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemReadListener;

import br.com.b3.batch.geraoperacoeseventovcp.model.Evento;

public class EventoItemReaderListener implements ItemReadListener<Evento> {

	private static final Logger LOGGER = LoggerFactory.getLogger(EventoItemReaderListener.class);
	@Override
	public void afterRead(Evento evento) {
		LOGGER.debug(this + " -> evento lido [" + evento.getNumEvento() + "]"); // + System.currentTimeMillis());
	}

	@Override
	public void beforeRead() {
		LOGGER.debug(this + " -> beforeRead -> " + System.currentTimeMillis() );
	}

	@Override
	public void onReadError(Exception e) {
		LOGGER.debug("onReadError");
		e.printStackTrace();	
	}
	
	
}
