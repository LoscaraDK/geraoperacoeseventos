package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the OPERACAO database table.
 * 
 */
@Entity
@Table(name = "TCTPOPERACAO_SPRING", schema = "CETIP")
@NamedQuery(name = "Operacao.findAll", query = "SELECT o FROM Operacao o")
public class Operacao implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="SEQUENCE_OPERACAO" )
	@SequenceGenerator(schema="CETIP", name="SEQUENCE_OPERACAO" , sequenceName="STCTPOPERACAO_SPRING", allocationSize = 1 )
	@Column(name = "NUM_ID_OPERACAO")
	private Long numIdOperacao;
	
	@Column(name = "COD_OPERACAO")
	private String codOperacao;

	@Column(name = "COD_CTL_PROCESSAMENTO")
	private String codCtlProcessamento;

	@Column(name = "QTD_OPERACAO")
	private Long qtdOperacao;

	@ManyToOne
	@JoinColumn(name = "NUM_EVENTO")
	private Evento evento;
	
	@Column(name = "COD_SITUACAO_OPERACAO")
	private int codSituacaoOperacao;
	
	@Column(name = "COD_TIPO_DEBITO_P1")
	private int codTipoDebitoP1;

	@Column(name = "COD_TIPO_DEBITO_P2")
	private int codTipoDebitoP2;
	
	@Column(name = "NUM_CONTA_PARTICIPANTE_P1")
	private Long numContaParticipanteP1;

	@Column(name = "NUM_CONTA_PARTICIPANTE_P2")
	private Long numContaParticipanteP2;
	
	@Column(name = "NUM_ID_ENTIDADE_P1")
	private Long numIdEntidadeP1;

	@Column(name = "NUM_ID_ENTIDADE_P2")
	private Long numIdEntidadeP2;

	@Column(name = "NUM_ID_TIPO_OPER_OBJETO_SERV")
	private Integer numIdTipoOperObjetoServ;

	@Column(name = "NUM_ID_MODALIDADE_LIQUIDACAO")
	private Integer numIdModalidadeLiquidacao;
	
	@Column(name = "NUM_CONTROLE_LANCAMENTO_P1")
	private String numControleLancamentoP1;

	@Column(name = "NUM_CONTROLE_LANCAMENTO_P2")
	private String numControleLancamentoP2;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_OPERACAO")
	private Date datOperacao;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_FINANCEIRO")
	private Date datFinanceiro;
	
	@Column(name = "VAL_FINANCEIRO")
	private BigDecimal valFinanceiro;

	@Column(name = "VAL_PRECO_UNITARIO")
	private BigDecimal valPrecoUnitario;
	
	@Column(name = "NUM_ASSOCIACAO")
	private Long numAssociacao;
	
	@Column(name = "NUM_ORDEM_ASSOCIACAO")
	private int numOrdemAssociacao;
	
	@Column(name = "QTD_MEMBROS_ASSOCIACAO")
	private int qtdMembrosAssociacao;
	
	@Column(name = "IND_LANCADO_P1")
	private String indLancadoP1;

	@Column(name = "IND_LANCADO_P2")
	private String indLancadoP2;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_ALTERACAO")
	private Date datAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_EXCLUSAO")
	private Date datExclusao;

	@Temporal(TemporalType.DATE)
	@Column(name = "DAT_INCLUSAO")
	private Date datInclusao;
	
	@Column(name = "IND_ASSOCIACAO")
	private String indAssociacao;
	
	@Column(name = "IND_EVENTOS_CURSADOS_CETIP")
	private String indEventosCursadosCetip;
	
	@Column(name = "IND_IDENTIFICACAO_AUTOMATICA")
	private String indIdentificacaoAutomatica;
	
	@Column(name = "NUM_ID_PARTE")
	private Long numIdParte;
	
	@Column(name = "NOM_SIMPLIFICADO_PARTE")
	private String nomSimplificadoParte;
		
	@Column(name = "NUM_ID_CONTRAPARTE")
	private Long numIdContraparte;
	
	@Column(name = "NUM_CONTA_ESCRITURADOR")
	private Long numContaEscriturador;
	
	@Column(name = "NUM_IF")
	private Long numIF;

	@Column(name = "TXT_HISTORICO")
	private String historico;

	public Long getNumIdOperacao() {
		return numIdOperacao;
	}

	public void setNumIdOperacao(Long numIdOperacao) {
		this.numIdOperacao = numIdOperacao;
	}

	public String getCodOperacao() {
		return codOperacao;
	}

	public void setCodOperacao(String codOperacao) {
		this.codOperacao = codOperacao;
	}

	public String getCodCtlProcessamento() {
		return codCtlProcessamento;
	}

	public void setCodCtlProcessamento(String codCtlProcessamento) {
		this.codCtlProcessamento = codCtlProcessamento;
	}

	public Long getQtdOperacao() {
		return qtdOperacao;
	}

	public void setQtdOperacao(Long qtdOperacao) {
		this.qtdOperacao = qtdOperacao;
	}

	public Evento getEvento() {
		return evento;
	}

	public void setEvento(Evento evento) {
		this.evento = evento;
	}

	public int getCodSituacaoOperacao() {
		return codSituacaoOperacao;
	}

	public void setCodSituacaoOperacao(int codSituacaoOperacao) {
		this.codSituacaoOperacao = codSituacaoOperacao;
	}

	public int getCodTipoDebitoP1() {
		return codTipoDebitoP1;
	}

	public void setCodTipoDebitoP1(int codTipoDebitoP1) {
		this.codTipoDebitoP1 = codTipoDebitoP1;
	}

	public int getCodTipoDebitoP2() {
		return codTipoDebitoP2;
	}

	public void setCodTipoDebitoP2(int codTipoDebitoP2) {
		this.codTipoDebitoP2 = codTipoDebitoP2;
	}

	public Long getNumContaParticipanteP1() {
		return numContaParticipanteP1;
	}

	public void setNumContaParticipanteP1(Long numContaParticipanteP1) {
		this.numContaParticipanteP1 = numContaParticipanteP1;
	}

	public Long getNumContaParticipanteP2() {
		return numContaParticipanteP2;
	}

	public void setNumContaParticipanteP2(Long numContaParticipanteP2) {
		this.numContaParticipanteP2 = numContaParticipanteP2;
	}

	public Long getNumIdEntidadeP1() {
		return numIdEntidadeP1;
	}

	public void setNumIdEntidadeP1(Long numIdEntidadeP1) {
		this.numIdEntidadeP1 = numIdEntidadeP1;
	}

	public Long getNumIdEntidadeP2() {
		return numIdEntidadeP2;
	}

	public void setNumIdEntidadeP2(Long numIdEntidadeP2) {
		this.numIdEntidadeP2 = numIdEntidadeP2;
	}

	public Integer getNumIdTipoOperObjetoServ() {
		return numIdTipoOperObjetoServ;
	}

	public void setNumIdTipoOperObjetoServ(Integer numIdTipoOperObjetoServ) {
		this.numIdTipoOperObjetoServ = numIdTipoOperObjetoServ;
	}

	public Integer getNumIdModalidadeLiquidacao() {
		return numIdModalidadeLiquidacao;
	}

	public void setNumIdModalidadeLiquidacao(Integer numIdModalidadeLiquidacao) {
		this.numIdModalidadeLiquidacao = numIdModalidadeLiquidacao;
	}

	public String getNumControleLancamentoP1() {
		return numControleLancamentoP1;
	}

	public void setNumControleLancamentoP1(String numControleLancamentoP1) {
		this.numControleLancamentoP1 = numControleLancamentoP1;
	}

	public String getNumControleLancamentoP2() {
		return numControleLancamentoP2;
	}

	public void setNumControleLancamentoP2(String numControleLancamentoP2) {
		this.numControleLancamentoP2 = numControleLancamentoP2;
	}

	public Date getDatOperacao() {
		return datOperacao;
	}

	public void setDatOperacao(Date datOperacao) {
		this.datOperacao = datOperacao;
	}

	public Date getDatFinanceiro() {
		return datFinanceiro;
	}

	public void setDatFinanceiro(Date datFinanceiro) {
		this.datFinanceiro = datFinanceiro;
	}

	public BigDecimal getValFinanceiro() {
		return valFinanceiro;
	}

	public void setValFinanceiro(BigDecimal valFinanceiro) {
		this.valFinanceiro = valFinanceiro;
	}

	public BigDecimal getValPrecoUnitario() {
		return valPrecoUnitario;
	}

	public void setValPrecoUnitario(BigDecimal valPrecoUnitario) {
		this.valPrecoUnitario = valPrecoUnitario;
	}

	public Long getNumAssociacao() {
		return numAssociacao;
	}

	public void setNumAssociacao(Long numAssociacao) {
		this.numAssociacao = numAssociacao;
	}

	public int getNumOrdemAssociacao() {
		return numOrdemAssociacao;
	}

	public void setNumOrdemAssociacao(int numOrdemAssociacao) {
		this.numOrdemAssociacao = numOrdemAssociacao;
	}

	public int getQtdMembrosAssociacao() {
		return qtdMembrosAssociacao;
	}

	public void setQtdMembrosAssociacao(int qtdMembrosAssociacao) {
		this.qtdMembrosAssociacao = qtdMembrosAssociacao;
	}

	public String getIndLancadoP1() {
		return indLancadoP1;
	}

	public void setIndLancadoP1(String indLancadoP1) {
		this.indLancadoP1 = indLancadoP1;
	}

	public String getIndLancadoP2() {
		return indLancadoP2;
	}

	public void setIndLancadoP2(String indLancadoP2) {
		this.indLancadoP2 = indLancadoP2;
	}

	public Date getDatAlteracao() {
		return datAlteracao;
	}

	public void setDatAlteracao(Date datAlteracao) {
		this.datAlteracao = datAlteracao;
	}

	public Date getDatExclusao() {
		return datExclusao;
	}

	public void setDatExclusao(Date datExclusao) {
		this.datExclusao = datExclusao;
	}

	public Date getDatInclusao() {
		return datInclusao;
	}

	public void setDatInclusao(Date datInclusao) {
		this.datInclusao = datInclusao;
	}

	public String getIndAssociacao() {
		return indAssociacao;
	}

	public void setIndAssociacao(String indAssociacao) {
		this.indAssociacao = indAssociacao;
	}

	public String getIndEventosCursadosCetip() {
		return indEventosCursadosCetip;
	}

	public void setIndEventosCursadosCetip(String indEventosCursadosCetip) {
		this.indEventosCursadosCetip = indEventosCursadosCetip;
	}

	public String getIndIdentificacaoAutomatica() {
		return indIdentificacaoAutomatica;
	}

	public void setIndIdentificacaoAutomatica(String indIdentificacaoAutomatica) {
		this.indIdentificacaoAutomatica = indIdentificacaoAutomatica;
	}

	public Long getNumIdParte() {
		return numIdParte;
	}

	public void setNumIdParte(Long numIdParte) {
		this.numIdParte = numIdParte;
	}

	public String getNomSimplificadoParte() {
		return nomSimplificadoParte;
	}

	public void setNomSimplificadoParte(String nomSimplificadoParte) {
		this.nomSimplificadoParte = nomSimplificadoParte;
	}

	public Long getNumIdContraparte() {
		return numIdContraparte;
	}

	public void setNumIdContraparte(Long numIdContraparte) {
		this.numIdContraparte = numIdContraparte;
	}

	public Long getNumContaEscriturador() {
		return numContaEscriturador;
	}

	public void setNumContaEscriturador(Long numContaEscriturador) {
		this.numContaEscriturador = numContaEscriturador;
	}

	public Long getNumIF() {
		return numIF;
	}

	public void setNumIF(Long numIF) {
		this.numIF = numIF;
	}

	public String getHistorico() {
		return historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}

	

	

}