package br.com.b3.batch.geraoperacoeseventovcp.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;

@Configuration
@PropertySources({
	@PropertySource("application-dev.properties"),
	@PropertySource("application-int.properties"),
	@PropertySource("application-hom.properties"),
	@PropertySource("application-preprod.properties"),
	@PropertySource("application-prod.properties"),
})
public class JasyptConfigStarter {

}
