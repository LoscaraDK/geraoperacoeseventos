package br.com.b3.batch.geraoperacoeseventovcp.service;

import java.util.Arrays;
import java.util.Collections;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.b3.batch.geraoperacoeseventovcp.model.ContaParticipante;
import br.com.b3.batch.geraoperacoeseventovcp.repository.ContaParticipanteRespoitory;
import br.com.b3.batch.geraoperacoeseventovcp.util.Constantes;

@Service
public class ContasService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ContasService.class);
	private static final Integer[] SITUACOES_CONTA = {Constantes.SITUACAO_CONTA_ATIVA,Constantes.SITUACAO_CONTA_ATIVA_SOMENTE_RESGATE};
	@Autowired
	private ContaParticipanteRespoitory contaParticipanteRespoitory;
	
	public boolean eContaInativa(Long numContaParticipante) {
		boolean retorno = contaParticipanteRespoitory.
							findAllByNumContaParticipanteAndNumIdSituacaoContaIn(numContaParticipante, 
																				Collections.unmodifiableList(Arrays.asList(SITUACOES_CONTA))).isEmpty();
		
		return retorno;
	}
	
	public ContaParticipante obterContaParticipantePorId(Long numContaParticipante) {
		return contaParticipanteRespoitory.findByNumContaParticipante(numContaParticipante);
	}
}
