package br.com.b3.batch.geraoperacoeseventovcp.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.b3.batch.geraoperacoeseventovcp.model.ContaParticipante;

public interface ContaParticipanteRespoitory extends JpaRepository<ContaParticipante, Long> {
	public List<ContaParticipante> findAllByNumContaParticipanteAndNumIdSituacaoContaIn(Long numContaParticipante, List<Integer> situacoes);
	public ContaParticipante findByNumContaParticipante(Long numContaParticipante);
}
