package br.com.b3.batch.geraoperacoeseventovcp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.b3.batch.geraoperacoeseventovcp.model.VctpEventosRetirados;

public interface VctpEventosRetiradosRepository extends JpaRepository<VctpEventosRetirados, Long> {
	
	@Query("SELECT COUNT(e) FROM VctpEventosRetirados e WHERE e.numEvento = :numEvento AND  (e.numContaParticipante = :numContaParticipante OR e.numContaParticipante is null)")
	Integer getCountEventosRetirados(@Param("numEvento") Long numEvento, @Param("numContaParticipante") Long numContaParticipanteP2);
}
