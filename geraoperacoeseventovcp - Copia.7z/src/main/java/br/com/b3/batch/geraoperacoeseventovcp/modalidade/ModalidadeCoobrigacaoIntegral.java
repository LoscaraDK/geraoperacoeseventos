package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.ESTADO_EVENTO_ATUALIZADO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_BRUTA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_SEM;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.NAO_ABREVIADO;

import java.math.BigDecimal;

public class ModalidadeCoobrigacaoIntegral extends AbstractModalidade {

	private Integer modalidadeDetalhada;

	public Integer getModalidadeDetalhada() {
		return modalidadeDetalhada;
	}

	private void setModalidadeDetalhada(Integer modalidadeDetalhada) {
		this.modalidadeDetalhada = modalidadeDetalhada;
	}

	@Override
	public ModalidadeContext selecionaModalidade(ModalidadeContext context) {

		Integer grpModalidadeAjustada = ajustaGrupoModalidade(context.getParameters(), GRP_MODALIDADE_CETIP);


		if(context.getParameters().getIndEventosCursadosCetip() != null && 
				NAO_ABREVIADO.equals(context.getParameters().getIndEventosCursadosCetip())) {
				grpModalidadeAjustada = GRP_MODALIDADE_SEM;
		}

		if (GRP_MODALIDADE_BRUTA.equals(grpModalidadeAjustada) || GRP_MODALIDADE_CETIP.equals(grpModalidadeAjustada)) {
			if (ESTADO_EVENTO_ATUALIZADO.equals(context.getParameters().getEstadoEvento())
					&& context.getParameters().getValorFinanceiro() != null
					&& context.getParameters().getValorFinanceiro().compareTo(new BigDecimal("0")) == 0

			) {
				grpModalidadeAjustada = GRP_MODALIDADE_SEM;
			}
		}
		
		if(context.getParameters().getIndVencidoInadimplido() == null && 
				!GRP_MODALIDADE_SEM.equals(grpModalidadeAjustada)
				) {
				grpModalidadeAjustada = GRP_MODALIDADE_BRUTA;
		}
		
		setModalidadeDetalhada(ajustaModalidadeLiquidacao(context.getParameters(), grpModalidadeAjustada));
		
		return context;
	}
}
