package br.com.b3.batch.geraoperacoeseventovcp.state;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.b3.batch.geraoperacoeseventovcp.util.Constantes;

public class SituacaoOperacaoContext{
	private OperacaoState current;
	private ParametersVO parameters;
	private static final Logger LOGGER = LoggerFactory.getLogger(SituacaoOperacaoContext.class);
	public SituacaoOperacaoContext(OperacaoState current, ParametersVO parameters) {
		this.current = current;
		this.parameters = parameters;
		
		if(current == null) {
			this.current = CancelRegistradorBloqueadoState.instance();
		}
	}

	public OperacaoState getCurrent() {
		return current;
	}

	public void setCurrent(OperacaoState current) {
		this.current = current;
	}

	public ParametersVO getParameters() {
		return parameters;
	}

	public void setParameters(ParametersVO parameters) {
		this.parameters = parameters;
	}
	
	public SituacaoOperacaoContext next() throws Exception{
		LOGGER.debug(this + " -> CURRENT -> " + current);
		LOGGER.debug(this + " -> THIS -> " + this);
		current.updateState(this);
		return this;
	}
	
	public static void main(String[] args) throws Exception {
		ParametersVO vo = new ParametersVO.ParametersBuilder()
							.addContaP1Inativa(false)
							.addContaP2Inativa(false)
							.addEstadoEvento(19)
							.addModalidade(Constantes.MODALIDADE_CETIP)
							.addNumTipoEventoLegado(84)
							.addRetiradoPorSolicitacao(true)
							.build();
		SituacaoOperacaoContext ctx = new SituacaoOperacaoContext(null, vo);
		ctx.next();
	}
}
