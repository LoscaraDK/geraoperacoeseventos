package br.com.b3.batch.geraoperacoeseventovcp.service;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import br.com.b3.batch.geraoperacoeseventovcp.repository.FunctionsRepository;

@Service
public class UtilsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(UtilsService.class);
	@Autowired
	private FunctionsRepository functionsRepository;
	
	public String geraCodigoOperacao() {
		return functionsRepository.callGetCodigoOperacao();
	}
	
	@Cacheable(key = "'dZero'", value = "dataHoje" )
	public Date getDataHoje() {
		return functionsRepository.callGetDZero();
	}
}
