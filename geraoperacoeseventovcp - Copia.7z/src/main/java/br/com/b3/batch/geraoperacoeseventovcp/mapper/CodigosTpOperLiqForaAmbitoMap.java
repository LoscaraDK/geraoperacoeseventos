package br.com.b3.batch.geraoperacoeseventovcp.mapper;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.*;
import java.util.HashMap;
import java.util.Map;

public class CodigosTpOperLiqForaAmbitoMap implements CodigoMap {
	
	private static CodigosTpOperLiqForaAmbitoMap instance = new CodigosTpOperLiqForaAmbitoMap();
	
	private CodigosTpOperLiqForaAmbitoMap() {}
	
	public static CodigoMap instance() {
		return instance;
	}
	
	private static Map<Integer, Integer> mapaTipoOpersParaTipoEventos;
	static {
		mapaTipoOpersParaTipoEventos = new HashMap<Integer, Integer>();
		mapaTipoOpersParaTipoEventos.put(TIPO_EVENTO_VENCIMENTO,TIPO_OPERACAO_VENCIMENTO);
		mapaTipoOpersParaTipoEventos.put(TIPO_EVENTO_PAGAMENTO_JUROS,TIPO_OPERACAO_PAGAMENTO_JUROS_SEM_FINANCEIRO);
		mapaTipoOpersParaTipoEventos.put(TIPO_EVENTO_INCORPORACAO_JUROS,TIPO_OPERACAO_INCORPORACAO_JUROS);
		mapaTipoOpersParaTipoEventos.put(TIPO_EVENTO_PAGAMENTO_RENDIMENTO,TIPO_OPERACAO_PAGAMENTO_RENDIMENTO);
		mapaTipoOpersParaTipoEventos.put(TIPO_EVENTO_AMORTIZACAO,TIPO_OPERACAO_AMORTIZACAO_SEM_FINANCEIRO);
		mapaTipoOpersParaTipoEventos.put(TIPO_EVENTO_ANTECIPACAO_PARCELA,TIPO_OPERACAO_ANTECIPACAO_PARCELA);
		mapaTipoOpersParaTipoEventos.put(TIPO_EVENTO_AMORTIZACAO_EXTRAORDINARIA,TIPO_OPERACAO_AMORTIZACAO_EXTRAORDINARIA);
		mapaTipoOpersParaTipoEventos.put(TIPO_EVENTO_PAGAMENTO_PARCELA,TIPO_OPERACAO_PAGAMENTO_PARCELA);
	}
	
	private Integer codigoTipoOperacao;
	private void setCodigoTipoOperacao(Integer codigoTipoOperacao) {
		this.codigoTipoOperacao = codigoTipoOperacao;
	}
	
	public Integer getCodigoTipoOperacao() {
		return this.codigoTipoOperacao;
	}
	
	@Override
	public void seleciona(SelecionaMapContext selecionaMapContext) {
		setCodigoTipoOperacao(mapaTipoOpersParaTipoEventos.get(selecionaMapContext.getNumTipoEventoLegado()));
	}

}
