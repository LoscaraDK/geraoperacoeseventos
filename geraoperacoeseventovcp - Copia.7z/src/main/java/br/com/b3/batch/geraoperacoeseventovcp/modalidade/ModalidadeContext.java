package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.*;

import java.util.HashMap;
import java.util.Map;

public class ModalidadeContext {
	
	private ModalidadeStrategy strategy;
	private ModalidadeParameters parameters;
	
	private ModalidadeContext() {}
	
	private ModalidadeContext(ModalidadeParameters parameters) {
		this.parameters = parameters;
		Integer numIdFormaPagamento = null;
		
		if(CCB_LIQUIDACAO_FORA_AMBITO_B3.equals(parameters.getNumIdFormaPagamento())) {
			numIdFormaPagamento = CCB_LIQUIDACAO_FORA_AMBITO_B3;
		}
		this.strategy = FactoryEstrategySelector.instance().getStrategy(new StrategySelector(parameters.getCodCoobrigacao(), numIdFormaPagamento));
	}
	
	public static ModalidadeContext instance(ModalidadeParameters parameters) {
		return new ModalidadeContext(parameters);
	}
	
	public ModalidadeParameters getParameters() {
		return this.parameters;
	}
	
	public ModalidadeStrategy getStrategy() {
		return this.strategy;
	}
	
	public ModalidadeContext execute () {
		return strategy.selecionaModalidade(this);
	}
}
