package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

import java.util.Objects;

public class StrategySelector {
	private String codTipoCoobrigacao; 
	private Integer numIdTipoFormaPagamento;
	
	public StrategySelector(String codTipoCoobrigacao, Integer numIdTipoFormaPagamento) {
		this.codTipoCoobrigacao = codTipoCoobrigacao;
		this.numIdTipoFormaPagamento = numIdTipoFormaPagamento;
	}

	public String getCodTipoCoobrigacao() {
		return this.codTipoCoobrigacao;
	}

	public Integer getNumIdTipoFormaPagamento() {
		return this.numIdTipoFormaPagamento;
	}
	
	@Override
	public int hashCode() {
		
		return Objects.hash(this.codTipoCoobrigacao,this.numIdTipoFormaPagamento);
	}
}
