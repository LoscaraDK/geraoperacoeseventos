package br.com.b3.batch.geraoperacoeseventovcp.components;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;
import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpD1Outro;
import br.com.b3.batch.geraoperacoeseventovcp.tradutor.Transform;

@Component (value = "ccbVcpD1OutroProcessor")
public class CcbVcpD1OutroProcessor implements ItemProcessor<VctpgopCcbVcpD1Outro, Operacao> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CcbVcpD1OutroProcessor.class);
	
	@Autowired
	private Transform transform;
	
	@Override
	public Operacao process(VctpgopCcbVcpD1Outro evento) throws Exception {
		LOGGER.debug("Evento id = " + evento.getEvento());
		
		Operacao operacao = transform.process(evento);
		
		return operacao;
	}
	
}
