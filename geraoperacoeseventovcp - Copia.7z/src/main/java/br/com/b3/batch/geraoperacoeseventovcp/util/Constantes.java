package br.com.b3.batch.geraoperacoeseventovcp.util;

/**
 * @author danielc
 *
 */
public interface Constantes {
 	/**
	1	Cetip
 	2	Bruta STR
	4	Bruta BT
	6	SEM MODALIDADE DE LIQUIDACAO
	11	Bruta BT AUT
	12	Bilateral STR
	13	Bilateral BT
	14	Eventos SELIC
	16	SEM MODALIDADE CCP
	15	CCP Cetip
	17	CCP Intraday	
	 */
	public static final Integer MODALIDADE_BILATERAL_BT = 13;
	public static final Integer MODALIDADE_BILATERAL_STR = 12;
	public static final Integer MODALIDADE_BRUTA_STR = 2;
	public static final Integer MODALIDADE_BRUTA_BT = 4;
	public static final Integer MODALIDADE_BRUTA_BT_AUT = 11;
	public static final Integer MODALIDADE_CETIP = 1;
	public static final Integer MODALIDADE_SEM = 6;
	
	/**
	0	SEM MODALIDADE DE LIQUIDACAO
	1	Cetip
	2	Bruta
	4	Bilateral
	5	SELIC
	7	SEM MODALIDADE CCP
	6	CCP Cetip
	*/
	public static final Integer GRP_MODALIDADE_SEM 	 		= 0;
	public static final Integer GRP_MODALIDADE_CETIP 		= 1;
	public static final Integer GRP_MODALIDADE_BRUTA 		= 2;
	public static final Integer GRP_MODALIDADE_BILATERAL 	= 4;
	
	
	public static final String COD_COOBRIGACAO_SEM_COOBRIGACAO  	= "SEM COOBRIGACAO";
	public static final String COD_COOBRIGACAO_INTEGRAL				= "INTEGRAL";
	public static final String COD_COOBRIGACAO_PARCIAL				= "PARCIAL";
	
	/**
	1	ATIVA
	2	ATIVA SOMENTE PARA RESGATE
	3	BLOQUEADA
	4	ENCERRADA
	11	EM PROCESSO DE ABERTURA
	12	EM PROCESSO DE REABERTURA
	13	EM PROCESSO DE ENCERRAMENTO
	*/
	public static final Integer SITUACAO_CONTA_ATIVA= 1;
	public static final Integer SITUACAO_CONTA_ATIVA_SOMENTE_RESGATE = 2;
	
	/** ESTADO EVENTO
	1	EVENTO NAO PROCESSADO
	2	EVENTO FINALIZADO
	3	REPROCESSA EVENTO
	4	PEND: RETIRADO EVENTO
	5	INFORMACAO DE PU ANTECIPADO
	6	PU NAO INFORMADO
	7	INFORMACAO DO PU NO DIA
	8	RETIRADO: EVENTO
	9	INFORMAR PU
	10	CANCELADO: EVENTO
	11	INFORMAR TAXA AMORTIZACAO
	12	INFORMAR PU PREFIXADO
	13	INFORMACAO DE PU PREFIXADO
	14	EVENTO ATUALIZADO
	15	ATIVO
	16	AGUARDANDO LIQUIDAÇÃO
	17	LIQUIDADO
	18	NÃO LIQUIDADO
	19	ATU: RETIRADO EVENTO
	20	PU CALCULADO PELO SISTEMA
	21	INADIMPLENTE: PU NAO LANCADO
	22	INADIMPLENTE: SEM BANCO LIQUIDANTE
	23	AGUARDANDO HORÁRIO LIMITE PARA LANCAMENTO DO PU
	24	PROCESSADO SEM FINANCEIRO
	25	INADIMPLENTE: NÃO LIQUIDADO FORA DO SND
	26	LIQUIDADO FORA DO SND
	27	EXCLUÍDO
	28	REPROGRAMADO
	29	INFORMAR PU FORA DO AMBITO DA CETIP
	30	RETIRADO POR INADIMPLENCIA
	31	ANTECIPADO
	34	PARCIAL
	35	TOTAL
	36	BARREIRA DE CUPOM NÃO ATINGIDA
	37	BARREIRA DE CHAMADA NÃO ATINGIDA
	38	BARREIRA DE CHAMADA ATINGIDA
	39	PEND: PARTE FIXA
	40	AGUARDANDO MARCAÇÃO A MERCADO
	41	MARCAÇÃO A MERCADO NÃO REALIZADA
	44	AGUARDANDO PGTO DE DERIVATIVO COM DRRC
	45	AGUARDANDO EVENTO DE DERIVATIVO
	46	PARCELA ADIMPLENTE
	47	PARCELA INADIMPLENTE
	*/
	public static final Integer ESTADO_EVENTO_ATUALIZADO = 14;
	public static final Integer ESTADO_EVENTO_INFORMACAO_PU_ANTECIPADO = 5;
	public static final Integer ESTADO_EVENTO_INFORMACAO_PU_PREFIXADO = 13;
	public static final Integer ESTADO_EVENTO_INFORMAR_PU = 9;
	public static final Integer ESTADO_EVENTO_INFORMACAO_PU_DIA = 7;
	public static final Integer ESTADO_EVENTO_ATU_RETIRADO_EVENTO = 19;
	public static final Integer ESTADO_EVENTO_PU_CALCULADO_PELO_SISTEMA = 20;
	public static final Integer ESTADO_EVENTO_LIQUIDACAO_FORA_AMBITO = 29;
	
	/**
	TIPO_OPERACAO											TIPOS DE EVENTO 
		9	VENCIMENTO SEM FINANCEIRO				- 		85 	VENCIMENTO (RESGATE) 				--NAO INCLUIDO
		12	RESGATE 								- 		85 	VENCIMENTO (RESGATE)
		60	PAGAMENTO DE JUROS						- 		83 	PAGAMENTO DE JUROS
		65	INCORPORACAO DE JUROS					- 		89 	INCORPORACAO DE JUROS
		69	PAGAMENTO DE RENDIMENTOS 				- 		90 	PAGAMENTO DE RENDIMENTO
		74	AMORTIZACAO PROGRAMADA 					- 		84 	AMORTIZACAO
	  	779 ANTECIPACAO DE PARCELA					- 		209 ANTECIPACAO DE PARCELA				ENTENDER A REGRA P/ ESCOLHA DE MODALIDADE	
	  	874 AMORTIZACAO EXTRAORDINARIA				-		97	AMORTIZACAO EXTRAORDINARIA
		878	PAGAMENTO PARCELA						-		157	PAGAMENTO DE PARCELA 
		960	PAGAMENTO DE JUROS SEM FINANCEIRO		- 		83 	PAGAMENTO DE JUROS     				--NAO INCLUIDO 
		974	AMORTIZACAO PROGRAMADA SEM FINANCEIRO	- 		84 	AMORTIZACAO							--NAO INCLUIDO
		873 PGTO. JUROS SOBRE AMORTIZACAO EXTRAORDINARIA  - ??  ?? 									--NAO INCLUIDO
	 */
	public static final Integer TIPO_EVENTO_VENCIMENTO = 85;
	public static final Integer TIPO_EVENTO_PAGAMENTO_JUROS = 83;
	public static final Integer TIPO_EVENTO_INCORPORACAO_JUROS = 89;
	public static final Integer TIPO_EVENTO_PAGAMENTO_RENDIMENTO = 90;
	public static final Integer TIPO_EVENTO_AMORTIZACAO = 84;
	public static final Integer TIPO_EVENTO_AMORTIZACAO_EXTRAORDINARIA = 97;
	public static final Integer TIPO_EVENTO_ANTECIPACAO_PARCELA = 209;
	public static final Integer TIPO_EVENTO_PAGAMENTO_PARCELA = 157;
	
	public static final Integer TIPO_OPERACAO_VENCIMENTO_SEM_FINANCEIRO = 9;
	public static final Integer TIPO_OPERACAO_VENCIMENTO = 12;
	public static final Integer TIPO_OPERACAO_PAGAMENTO_JUROS = 60;
	public static final Integer TIPO_OPERACAO_INCORPORACAO_JUROS = 65;
	public static final Integer TIPO_OPERACAO_PAGAMENTO_RENDIMENTO = 69;
	public static final Integer TIPO_OPERACAO_AMORTIZACAO = 74;
	public static final Integer TIPO_OPERACAO_ANTECIPACAO_PARCELA = 779;
	public static final Integer TIPO_OPERACAO_AMORTIZACAO_EXTRAORDINARIA = 874;
	public static final Integer TIPO_OPERACAO_PAGAMENTO_PARCELA = 878;
	public static final Integer TIPO_OPERACAO_PAGAMENTO_JUROS_SEM_FINANCEIRO = 960;
	public static final Integer TIPO_OPERACAO_AMORTIZACAO_SEM_FINANCEIRO = 974;
	
	/**
	9	PEND ATU: HORARIO
	13	CANCELADO: PARTIC BLOQ
	23	PENDENTE DE LIQUIDACAO FINANCEIRA
	43	FINALIZADA
	85	PEND ATU: VALOR
	87	RETIRADO: POR SOLICITACAO
	90	CANC: REGISTRADOR BLOQ
	231	PEND: LANC PU EVENTO
	400	PEND INT: CONFIRMACAO SALDO
	403	PEND INT:CONFIRMACAO PARTIC DESBLOQUEADO*/
	public Integer PEND_ATU_HORARIO = 9;
	public Integer CANCELADO_PARTICIPANTE_BLOQUEADO = 13;
	public Integer PENDENTE_LIQUIDACAO_FINANCEIRA = 23;
	public Integer FINALIZADA = 43;
	public Integer PEND_ATU_VALOR = 85;
	public Integer RETIRADO_POR_SOLICITACAO = 87;
	public Integer CANCELADO_REGISTRADOR_BLOQUEADO = 90;
	public Integer PEND_LANC_PU_EVENTO= 231;
	public Integer PEND_INT_CONFIRMACAO_SALDO = 400;
	public Integer PEND_INT_CONFIRMACAO_PARTICIPANTE_DESBLOQUEADO = 403;
	
	public String COD_CTL_PROCESSAMENTO_ERRO = "Y";
	public String COD_CTL_PROCESSAMENTO_AGUARDANDO = "B";
	public String COD_CTL_PROCESSAMENTO_PROCESSADO = "N";
	
	/**
	1	PROPRIA (00)
	5	CLIENTE 1 - GERAL (10)
	10	CLIENTE 2 - GERAL (20)
	20	EMISSORA CETIP (40)
	28	GARANTIA (60)
	 */
	public static final String TP_CONTA_PROPRIA  				= "00";
	public static final String TP_CONTA_CLIENTE_1				= "10";
	public static final String TP_CONTA_CLIENTE_2				= "20";
	public static final String TP_CONTA_EMISSORA				= "40";
	public static final String TP_CONTA_GARANTIA				= "60";
	public static final String TP_CONTA_BROKER 					= "69";
	
	public static final String SIM_ABREVIADO = "S";
	public static final String NAO_ABREVIADO = "N";
	
	/** FORMA PAGAMENTO
	1		Pagamento de juros e principal no vencimento
	2		Pagamento periódico de juros e principal no vencimento
	3		Pagamento de juros e amortização periódicos
	4		Pagamento de amortização periódica e juros no vencimento
	5		Tabela Price para CCB prefixada
	6		Pagamento de principal no vencimento sem taxa de juros
	7		Pagamento de amortização sem taxa de juros
	8		Pagamento de rendimento prefixado
	9		Pagamento de rendimento em aberto
	229		Pagamento de parcelas fixas
	3253	Liquidação fora do âmbito B3
	313		Pagamento de amortização e juros calculado sobre amortização
	*/
    public static final Integer CCB_JUROS_PRINCIPAL_VENCIMENTO = 1;
    public static final Integer CCB_JUROS_PERIODICO_PRINCIPAL_VENCIMENTO = 2;
    public static final Integer CCB_JUROS_AMORTIZACAO_PERIODICO = 3;
    public static final Integer CCB_AMORTIZACAO_PERIODICO_JUROS_VENCIMENTO = 4;
    public static final Integer CCB_TABELA_PRICE = 5;
    public static final Integer CCB_PRINCIPAL_VENCIMENTO_SEM_JUROS = 6;
    public static final Integer CCB_AMORTIZACAO_SEM_JUROS = 7;
    public static final Integer CCB_RENDIMENTO_PREFIXADO = 8;
    public static final Integer CCB_RENDIMENTO_ABERTO = 9;
    public static final Integer CCB_PARCELAS_FIXAS = 229;
    public static final Integer CCB_PGTO_AMORTIZACAO_E_JUROS_CALCULADO_SOBRE_AMORTIZACAO = 313;
    public static final Integer CCB_LIQUIDACAO_FORA_AMBITO_B3 = 3253;
    
    
    public static final Integer OBJETO_SERVICO_CCB = 47;
    
    
    public static final String[] COLUNAS_LINHA_ARQUIVO = new String[] { "codOperacao",
																		"numIF",
																		"qtdOperacao",
																		"codCtlProcessamento",
																		"codSituacaoOperacao",
																		"numContaParticipanteP1",
																		"numContaParticipanteP2",
																		"indLancadoP1",
																		"indLancadoP2",
																		"valPrecoUnitario",
																		"valFinanceiro",
																		"evento.numEvento",
																		"numIdModalidadeLiquidacao",
																		"datOperacao",
																		"datFinanceiro",
																		"numIdTipoOperObjetoServ",
																		"numIdEntidadeP1",
																		"numIdEntidadeP2",
																		"codTipoDebitoP1",
																		"codTipoDebitoP2",
																		"datInclusao",
																		"historico"};
    
    public static final String HEADER_LINHA_ARQUIVO = "COD_OPERACAO,NUM_IF,QTD_OPERACAO,COD_CTL_PROCESSAMENTO,COD_SITUACAO_OPERACAO,NUM_CONTA_PARTICIPANTE_P1,NUM_CONTA_PARTICIPANTE_P2,IND_LANCADO_P1,IND_LANCADO_P2,VAL_PRECO_UNITARIO,VAL_FINANCEIRO,NUM_EVENTO,NUM_ID_MODALIDADE_LIQUIDACAO,DAT_OPERACAO,DAT_FINANCEIRO,NUM_ID_TIPO_OPER_OBJETO_SERV,NUM_ID_ENTIDADE_P1,NUM_ID_ENTIDADE_P2,COD_TIPO_DEBITO_P1,COD_TIPO_DEBITO_P2,DAT_INCLUSAO,TXT_HISTORICO";
}
