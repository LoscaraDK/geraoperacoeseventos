package br.com.b3.batch.geraoperacoeseventovcp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpD1Outro;

@Repository
public interface CcbVcpD1OutroRepository extends JpaRepository<VctpgopCcbVcpD1Outro, Long> {

}


