package br.com.b3.batch.geraoperacoeseventovcp.config;

import java.util.concurrent.ThreadPoolExecutor;

import javax.sql.DataSource;

import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.explore.support.JobExplorerFactoryBean;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.JobRepositoryFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
public class SpringBatchConfig implements BatchConfigurer {

	private static final String BATCH_PROCESSING_PREFIX = "CETIP.BATCH_";

	@Autowired
	@Qualifier(value = "batch-datasource")
	public DataSource dataSource;

	@Autowired
	@Qualifier(value = "batchTransactionManager")
	public PlatformTransactionManager batchTransactionManager;

	@Override
	@Primary
	@Bean
	public JobExplorer getJobExplorer() throws Exception {
		JobExplorerFactoryBean factoryBean = new JobExplorerFactoryBean();
		factoryBean.setDataSource(dataSource);
		factoryBean.setTablePrefix(BATCH_PROCESSING_PREFIX);
		factoryBean.afterPropertiesSet();
		return factoryBean.getObject();
	}

	@Override
	@Primary
	@Bean
	public JobLauncher getJobLauncher() throws Exception {
		SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
		jobLauncher.setJobRepository(getJobRepository());
		jobLauncher.afterPropertiesSet();
		return jobLauncher;
	}

	@Override
	public JobRepository getJobRepository() throws Exception {
		JobRepositoryFactoryBean factoryBean = new JobRepositoryFactoryBean();
		factoryBean.setDataSource(dataSource);
		factoryBean.setTransactionManager(batchTransactionManager);
		factoryBean.setTablePrefix(BATCH_PROCESSING_PREFIX);
		factoryBean.setIsolationLevelForCreate("PROPAGATION_REQUIRED");
		factoryBean.setDatabaseType("ORACLE");
		factoryBean.afterPropertiesSet();
		return factoryBean.getObject();
	}

	@Override
	public PlatformTransactionManager getTransactionManager() throws Exception {
		// TODO Auto-generated method stub
		return batchTransactionManager;
	}
	
	@Bean(name = "taskExecutor")
	public ThreadPoolTaskExecutor createTaskExecutor() {
		ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
		taskExecutor.setCorePoolSize(64);
		taskExecutor.setMaxPoolSize(64);
		taskExecutor.setQueueCapacity(64);
		taskExecutor.setThreadNamePrefix("Thread-");
		taskExecutor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
		taskExecutor.afterPropertiesSet();

		return taskExecutor;
	}
}