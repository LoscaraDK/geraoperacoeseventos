package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the VCTPGOP_CCB_VCP_VEN_AMORT_RESG database table.
 * 
 */
@Entity
@Table(name="VCTPGOP_CCB_VCP_VEN_JUROS_REND", schema="CETIP")
@NamedQuery(name="VctpgopCcbVcpVenJurosRend.findAll", query="SELECT v FROM VctpgopCcbVcpVenJurosRend v")
public class VctpgopCcbVcpVenJurosRend extends BaseCcbVcp implements Serializable {}