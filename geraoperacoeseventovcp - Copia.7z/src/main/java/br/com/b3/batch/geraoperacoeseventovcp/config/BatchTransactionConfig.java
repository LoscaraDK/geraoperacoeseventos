package br.com.b3.batch.geraoperacoeseventovcp.config;

import java.util.Collections;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = "batchEntityManagerFactory", transactionManagerRef = "batchTransactionManager")
@EnableTransactionManagement
public class BatchTransactionConfig {
	@Primary
	@Bean(name = "batch-datasource")
	@ConfigurationProperties(prefix = "batch.datasource")
	public DataSource criarDatasourceBatch() {
		return DataSourceBuilder.create().build();
	}
	@Primary
	@Bean(name = "batchEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean batchEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("batch-datasource") DataSource datasource) {
		return builder.dataSource(datasource).packages("br.com.b3.batch.geraoperacoeseventovcp.model")
				.persistenceUnit("batchPersistence")
				.properties(Collections.singletonMap("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect"))
				.build();
	}
	@Primary
	@Bean(name = "batchTransactionManager")
	public PlatformTransactionManager batchTransactionManager(
			@Qualifier("batchEntityManagerFactory") EntityManagerFactory emFactory) {
		return new JpaTransactionManager(emFactory);
	}
}