package br.com.b3.batch.geraoperacoeseventovcp.config.flow;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.batch.core.partition.support.TaskExecutorPartitionHandler;
import org.springframework.batch.integration.async.AsyncItemProcessor;
import org.springframework.batch.integration.async.AsyncItemWriter;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import br.com.b3.batch.geraoperacoeseventovcp.components.CcbVcpVenOutroWriter;
import br.com.b3.batch.geraoperacoeseventovcp.config.EventosPartitioner;
import br.com.b3.batch.geraoperacoeseventovcp.listener.EventoStepListener;
import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;
import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpVenOutro;
import br.com.b3.batch.geraoperacoeseventovcp.service.EventoService;

@Configuration
public class CcbVcpVenOutroFlowConfig {
	private static final String NOME_PROCESSO = "CcbVcpVenOutro";
	private static final Logger LOGGER = LoggerFactory.getLogger(CcbVcpVenOutroFlowConfig.class);
	private static final int CHUNK_SIZE = 1000;	
	
	@Autowired
	@StepScope
	private CcbVcpVenOutroWriter writer;

	@Autowired
	@StepScope			 
	@Qualifier(value = "ccbVcpVenOutroProcessor")
	private ItemProcessor<VctpgopCcbVcpVenOutro, Operacao> converterProcessor;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	@Qualifier("nomeEntityManagerFactory")
	private EntityManagerFactory em;
	
	@Autowired
	@Qualifier("taskExecutor")
	private ThreadPoolTaskExecutor taskExecutor;
	
	@Autowired
	@Qualifier("eventoService")
	private EventoService service;
	
	@Bean(name= "flow" + NOME_PROCESSO )
	public Flow flow() throws Exception{
		return new FlowBuilder<SimpleFlow>("flow" + NOME_PROCESSO)
				.start(masterStep())
				.build();
	}
	
	@Bean (name = "masterStep" + NOME_PROCESSO)
	public Step masterStep() throws Exception{
		return stepBuilderFactory.get("masterStep" + NOME_PROCESSO)
				.partitioner(slaveStep().getName(),partitioner())
				.partitionHandler(handler())
				.build();
	}
	
	@Bean (name = "slaveStep" + NOME_PROCESSO)
	public Step slaveStep() throws Exception{
		return stepBuilderFactory.get("slaveStep" + NOME_PROCESSO)
				.listener(new EventoStepListener())
				.<VctpgopCcbVcpVenOutro, Operacao>chunk(CHUNK_SIZE)
				.reader(reader(null, null))
				.processor(processor())
				.writer(writer())
				.build();
	}
	
	@Bean (name = "reader" + NOME_PROCESSO)
	@StepScope
	public JpaPagingItemReader<VctpgopCcbVcpVenOutro> reader (
		      @Value("#{stepExecutionContext['minValue']}") Integer minValue,
		      @Value("#{stepExecutionContext['maxValue']}") Integer maxValue) throws Exception{
		LOGGER.debug(this + " -> minValue -> "+minValue + " to maxValue -> "+maxValue);
		JpaPagingItemReader<VctpgopCcbVcpVenOutro> readerJPA = new JpaPagingItemReader<VctpgopCcbVcpVenOutro>();
		readerJPA.setQueryString("select e from VctpgopCcbVcpVenOutro e where e.idView >= :minValue and e.idView <= :maxValue");
		readerJPA.setEntityManagerFactory(em);
		readerJPA.setPageSize(CHUNK_SIZE);
		
		Map<String, Object> params = new HashMap<>();
		params.put("minValue", new Long(minValue));
		params.put("maxValue", new Long(maxValue));
		readerJPA.setParameterValues(params);
		
		readerJPA.afterPropertiesSet();
		return readerJPA;
	}
	
	@Bean (name = "processor" + NOME_PROCESSO)
	public AsyncItemProcessor processor() throws Exception{
		 AsyncItemProcessor<VctpgopCcbVcpVenOutro, Operacao> processor = new AsyncItemProcessor<VctpgopCcbVcpVenOutro, Operacao>();
		 processor.setDelegate(converterProcessor);
		 processor.setTaskExecutor(taskExecutor);
		 return processor;
	}
	
	@Bean (name = "writer" + NOME_PROCESSO)
	public AsyncItemWriter<Operacao> writer() throws Exception{
		 AsyncItemWriter<Operacao> asyncWriter = new AsyncItemWriter<Operacao>();
		 asyncWriter.setDelegate(writer);
		 return asyncWriter;
	}
	
	@Bean (name = "partitioner" + NOME_PROCESSO)
	public EventosPartitioner partitioner() {
		EventosPartitioner eventosPartitioner = new EventosPartitioner();
		eventosPartitioner.setTotalLinhas(service.countEventosCcbVcpVenOutro());
		return eventosPartitioner;
	}
	
	@Bean (name = "handler" + NOME_PROCESSO)
	public PartitionHandler handler() throws Exception{
		TaskExecutorPartitionHandler handler = new TaskExecutorPartitionHandler();
		handler.setGridSize(8);
		handler.setTaskExecutor(taskExecutor);
		handler.setStep(slaveStep());
		
		return handler;
	}
}
