package br.com.b3.batch.geraoperacoeseventovcp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpVenJurosRend;

@Repository
public interface CcbVcpVenJurosRendRepository extends JpaRepository<VctpgopCcbVcpVenJurosRend, Long> {

}


