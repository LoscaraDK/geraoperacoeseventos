package br.com.b3.batch.geraoperacoeseventovcp.state;

import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.*;

public class OperacaoStateFactory {
	private OperacaoStateFactory() {}
	
	public static OperacaoStateFactory instance = new OperacaoStateFactory();
	
	public static OperacaoStateFactory instance () {
		return instance;
	}
	
	public OperacaoState getState(Integer numIdEstadoEvento) {
		OperacaoState state = null;
		
		if(ESTADO_EVENTO_ATUALIZADO.equals(numIdEstadoEvento) ||
				ESTADO_EVENTO_LIQUIDACAO_FORA_AMBITO.equals(numIdEstadoEvento)) { //	14	EVENTO ATUALIZADO /	29  LIQUIDACAO FORA DO AMBITO
			state =  EventoAtualizadoState.instance();
		}else if(ESTADO_EVENTO_INFORMACAO_PU_ANTECIPADO.equals(numIdEstadoEvento)) { //	5	INFORMACAO DE PU ANTECIPADO
			state = InformacaoPuAntecipadoState.instance();
		}else if(ESTADO_EVENTO_INFORMACAO_PU_PREFIXADO.equals(numIdEstadoEvento)) { //	13	INFORMACAO DE PU PREFIXADO
			state = InformacaoPuPrefixadoState.instance();
		}else if(ESTADO_EVENTO_INFORMAR_PU.equals(numIdEstadoEvento)) { //	9	INFORMAR PU
			state = InformarPuState.instance();
		}else if(ESTADO_EVENTO_INFORMACAO_PU_DIA.equals(numIdEstadoEvento)) { //	7	INFORMACAO DO PU NO DIA
			state = InformacaoPuNoDiaState.instance();
		}else if(ESTADO_EVENTO_ATU_RETIRADO_EVENTO.equals(numIdEstadoEvento)) { //	19	ATU: RETIRADO EVENTO
			state = AtuRetiradoEventoState.instance();
		}else if(ESTADO_EVENTO_PU_CALCULADO_PELO_SISTEMA.equals(numIdEstadoEvento)) { //	20	PU CALCULADO PELO SISTEMA
			state = PuCalculadoSistemaState.instance();
		}
		
		return state;
			
	}
}
