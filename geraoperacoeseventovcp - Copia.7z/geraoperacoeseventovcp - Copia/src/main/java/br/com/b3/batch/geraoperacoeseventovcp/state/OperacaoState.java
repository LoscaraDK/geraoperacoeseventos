package br.com.b3.batch.geraoperacoeseventovcp.state;

public interface OperacaoState {
	public void updateState(SituacaoOperacaoContext context) throws Exception;
	public Integer getSituacaoOperacao();
	public String  getCodCtlProcessamento();
	
}
