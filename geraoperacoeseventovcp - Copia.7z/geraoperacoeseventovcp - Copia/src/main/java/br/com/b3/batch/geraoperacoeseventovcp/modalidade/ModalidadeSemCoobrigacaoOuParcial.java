package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_COOBRIGACAO_PARCIAL;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.ESTADO_EVENTO_ATUALIZADO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.ESTADO_EVENTO_ATU_RETIRADO_EVENTO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_BRUTA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_SEM;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.NAO_ABREVIADO;

import java.math.BigDecimal;

public class ModalidadeSemCoobrigacaoOuParcial extends AbstractModalidade {
	
	private Integer modalidadeDetalhada;

	public Integer getModalidadeDetalhada() {
		return modalidadeDetalhada;
	}

	private void setModalidadeDetalhada(Integer modalidadeDetalhada) {
		this.modalidadeDetalhada = modalidadeDetalhada;
	}

	@Override
	public ModalidadeContext selecionaModalidade(ModalidadeContext context) {
		Integer grpModalidadeAjustada = ajustaGrupoModalidade(context.getParameters(), GRP_MODALIDADE_CETIP);

		Integer grpModalidadeAjustadaCetip = ajustaGrupoModalidade(context.getParameters(), GRP_MODALIDADE_BRUTA);

		Integer grpModalidadeAux = null;
		if (COD_COOBRIGACAO_PARCIAL.equals(context.getParameters().getCodCoobrigacao())) {
			grpModalidadeAux = grpModalidadeAjustadaCetip;
		}

		if (ESTADO_EVENTO_ATU_RETIRADO_EVENTO.equals(context.getParameters().getEstadoEvento())) {
			grpModalidadeAux = grpModalidadeAjustada;
		} else if (context.getParameters().getIndConfirmacaoPagamento() != null
				&& NAO_ABREVIADO.equals(context.getParameters().getIndConfirmacaoPagamento())) { // Evento retirado
			grpModalidadeAux = grpModalidadeAjustada;
		} else if (context.getParameters().getValPercentualPagamento() == null) { // evento pago total
			grpModalidadeAux = grpModalidadeAjustada;
		}
		
		if(context.getParameters().getIndEventosCursadosCetip() != null && 
				NAO_ABREVIADO.equals(context.getParameters().getIndEventosCursadosCetip())) {
			   grpModalidadeAux = GRP_MODALIDADE_SEM;
		}
		
		// operacoes com valor financeiro zero devem ser sem modalidade
		if (GRP_MODALIDADE_BRUTA.equals(grpModalidadeAux) || GRP_MODALIDADE_CETIP.equals(grpModalidadeAux)) {
			if (ESTADO_EVENTO_ATUALIZADO.equals(context.getParameters().getEstadoEvento())
					&& context.getParameters().getValorFinanceiro() != null
					&& context.getParameters().getValorFinanceiro().compareTo(new BigDecimal("0")) == 0

			) {
				grpModalidadeAux = GRP_MODALIDADE_SEM;
			}
		}
		
		if(context.getParameters().getIndVencidoInadimplido() == null && 
				!GRP_MODALIDADE_SEM.equals(grpModalidadeAux)
				) {
			   grpModalidadeAux = GRP_MODALIDADE_BRUTA;
		}

		setModalidadeDetalhada(ajustaModalidadeLiquidacao(context.getParameters(), grpModalidadeAux));

		return context;
	}
}
