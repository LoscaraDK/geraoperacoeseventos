package br.com.b3.batch.geraoperacoeseventovcp.components;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;
import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpD1JurosRend;
import br.com.b3.batch.geraoperacoeseventovcp.tradutor.Transform;

@Component (value = "ccbVcpD1JurosRendProcessor")
public class CcbVcpD1JurosRendProcessor implements ItemProcessor<VctpgopCcbVcpD1JurosRend, Operacao> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CcbVcpD1JurosRendProcessor.class);
	
	@Autowired
	private Transform transform;
	
	@Override
	public Operacao process(VctpgopCcbVcpD1JurosRend evento) throws Exception {
		LOGGER.debug("Evento id = " + evento.getEvento());
		
		Operacao operacao = transform.process(evento);
		
		return operacao;
	}
	
}
