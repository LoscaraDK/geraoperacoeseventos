package br.com.b3.batch.geraoperacoeseventovcp.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import br.com.b3.batch.geraoperacoeseventovcp.model.VSapDadosLiquidantesSimpl;

public interface VSapDadosLiquidantesSimplRepository extends JpaRepository<VSapDadosLiquidantesSimpl, Long> {
	VSapDadosLiquidantesSimpl findByNumContaLiquidada(Long numContaLiquidada);
}
