package br.com.b3.batch.geraoperacoeseventovcp.repository;

import java.util.Date;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import br.com.b3.batch.geraoperacoeseventovcp.model.Functions;

public interface FunctionsRepository extends JpaRepository<Functions, Long> {
//	cetip.get_cod_operacao
	@Query(nativeQuery = true , value = "select cetip.get_cod_operacao() from dual" )
	public String callGetCodigoOperacao();
	
	@Query(nativeQuery = true , value = "select cetip.GET_DATAHOJE from dual" )
	public Date callGetDZero();
	
}
