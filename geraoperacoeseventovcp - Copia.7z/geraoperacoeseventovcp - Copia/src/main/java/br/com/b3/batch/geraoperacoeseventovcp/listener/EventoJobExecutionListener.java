package br.com.b3.batch.geraoperacoeseventovcp.listener;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.metrics.MetricsEndpoint;
import org.springframework.stereotype.Component;

import br.com.b3.batch.geraoperacoeseventovcp.metrics.BatchAllJobsMetricContext;
import br.com.b3.batch.geraoperacoeseventovcp.metrics.BatchPerJobMetricContext;

@Component
public class EventoJobExecutionListener implements JobExecutionListener {
	
    @Autowired
    private MetricsEndpoint metricsEndpoint;

    @Autowired
    BatchAllJobsMetricContext batchAllJobsMetricContext;

    @Autowired
    BatchPerJobMetricContext batchPerJobMetricContext;

    @Override
    public void beforeJob(JobExecution jobExecution) {

    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        MetricsEndpoint.MetricResponse metricResponse = metricsEndpoint.metric("spring.batch.job",null);

        String key = jobExecution.getJobParameters().getString("converteEventosEmOperacoes");
        String execution = "Execution "+jobExecution.getJobParameters().getString("executionCount");
        if(batchAllJobsMetricContext.hasKey(key)){
           batchAllJobsMetricContext.get(key).put(execution,metricResponse);
        }else{
            batchPerJobMetricContext.put(execution,metricResponse);
            batchAllJobsMetricContext.put(key,batchPerJobMetricContext);
        }
        
        System.exit(ExitStatus.COMPLETED.equals(jobExecution.getExitStatus())? 0 : -1);
    }

}