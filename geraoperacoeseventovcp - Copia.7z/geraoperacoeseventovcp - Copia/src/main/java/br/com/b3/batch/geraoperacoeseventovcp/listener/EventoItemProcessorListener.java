package br.com.b3.batch.geraoperacoeseventovcp.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemProcessListener;

import br.com.b3.batch.geraoperacoeseventovcp.model.Evento;
import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;

public class EventoItemProcessorListener implements ItemProcessListener<Evento, Operacao> {

	private static final Logger LOGGER = LoggerFactory.getLogger(EventoItemProcessorListener.class);

	@Override
	public void afterProcess(Evento evento, Operacao operacao) {
		LOGGER.debug(this + " -> after process -> " + evento.getNumEvento() + " -> operacao do evento -> " + operacao.getEvento().getNumEvento());		
	}

	@Override
	public void beforeProcess(Evento arg0) {
		LOGGER.debug(this + " -> beforeProcess" );		
	}

	@Override
	public void onProcessError(Evento evento, Exception e) {
		LOGGER.debug("onProcessError -> " + evento.getNumEvento());
		e.printStackTrace();
	}
	
	
}
