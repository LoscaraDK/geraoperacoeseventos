package br.com.b3.batch.geraoperacoeseventovcp.state;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.CANCELADO_REGISTRADOR_BLOQUEADO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_PROCESSADO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
public class CancelRegistradorBloqueadoState implements OperacaoState{
	private static final Logger LOGGER = LoggerFactory.getLogger(CancelRegistradorBloqueadoState.class);
	private static CancelRegistradorBloqueadoState instance = new CancelRegistradorBloqueadoState();
	
	private CancelRegistradorBloqueadoState() {}
	
	public static CancelRegistradorBloqueadoState instance() {
		return instance;
	}
	
	@Override
	public String getCodCtlProcessamento() {
		return COD_CTL_PROCESSAMENTO_PROCESSADO;
	}
	
	public Integer getSituacaoOperacao() {
		return CANCELADO_REGISTRADOR_BLOQUEADO;
	}
	
	@Override
	public void updateState(SituacaoOperacaoContext context) throws Exception {
		LOGGER.debug(this + " -> " + context.getCurrent().getSituacaoOperacao());
		boolean eContaInativa = context.getParameters().eContaP1Inativa();
		if(!eContaInativa) {
			context.setCurrent(CancelParticipanteBloqueadoState.instance());
			context.next();
		}
	}

}
