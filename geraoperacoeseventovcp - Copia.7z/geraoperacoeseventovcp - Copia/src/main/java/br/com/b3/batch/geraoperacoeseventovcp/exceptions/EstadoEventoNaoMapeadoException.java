package br.com.b3.batch.geraoperacoeseventovcp.exceptions;

@SuppressWarnings("serial")
public class EstadoEventoNaoMapeadoException extends Exception {
	public EstadoEventoNaoMapeadoException(String mensagem) {
		super(mensagem);
	}
	
	public EstadoEventoNaoMapeadoException(String mensagem, Throwable throwable) {
		super(mensagem, throwable);
	}
}
