package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the VCTPEVENTOS_RETIRADOS database table.
 * 
 */
@Entity
@Table(name="VCTPEVENTOS_RETIRADOS", schema="CETIP")
@NamedQuery(name="VctpEventosRetirados.findAll", query="SELECT v FROM VctpEventosRetirados v")
public class VctpEventosRetirados implements Serializable {
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_EXCLUSAO")
	private Date datExclusao;

	@Column(name="NUM_CONTA_PARTICIPANTE")
	private Long numContaParticipante;

	@Column(name="NUM_ENTIDADE_ATUALIZ")
	private Long numEntidadeAtualiz;

	@Column(name="NUM_EVENTO")
	private Long numEvento;
	
	@Id
	@Column(name="NUM_ID_EVENTO_RETIRADA")
	private Long numIdEventoRetirada;

	@Column(name="TXT_MOTIVO")
	private String txtMotivo;

	public VctpEventosRetirados() {
	}

	public Date getDatExclusao() {
		return this.datExclusao;
	}

	public void setDatExclusao(Date datExclusao) {
		this.datExclusao = datExclusao;
	}

	public Long getNumContaParticipante() {
		return this.numContaParticipante;
	}

	public void setNumContaParticipante(Long numContaParticipante) {
		this.numContaParticipante = numContaParticipante;
	}

	public Long getNumEntidadeAtualiz() {
		return this.numEntidadeAtualiz;
	}

	public void setNumEntidadeAtualiz(Long numEntidadeAtualiz) {
		this.numEntidadeAtualiz = numEntidadeAtualiz;
	}

	public Long getNumEvento() {
		return this.numEvento;
	}

	public void setNumEvento(Long numEvento) {
		this.numEvento = numEvento;
	}

	public Long getNumIdEventoRetirada() {
		return this.numIdEventoRetirada;
	}

	public void setNumIdEventoRetirada(Long numIdEventoRetirada) {
		this.numIdEventoRetirada = numIdEventoRetirada;
	}

	public String getTxtMotivo() {
		return this.txtMotivo;
	}

	public void setTxtMotivo(String txtMotivo) {
		this.txtMotivo = txtMotivo;
	}

}