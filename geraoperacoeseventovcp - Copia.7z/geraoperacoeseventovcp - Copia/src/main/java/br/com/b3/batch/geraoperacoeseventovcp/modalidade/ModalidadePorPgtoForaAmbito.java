package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_SEM;

public class ModalidadePorPgtoForaAmbito extends AbstractModalidade {

	private Integer modalidadeDetalhada;

	public Integer getModalidadeDetalhada() {
		return modalidadeDetalhada;
	}

	private void setModalidadeDetalhada(Integer modalidadeDetalhada) {
		this.modalidadeDetalhada = modalidadeDetalhada;
	}

	@Override
	public ModalidadeContext selecionaModalidade(ModalidadeContext context) {
		
		setModalidadeDetalhada(ajustaModalidadeLiquidacao(context.getParameters(), GRP_MODALIDADE_SEM));
		
		return context;
	}
}
