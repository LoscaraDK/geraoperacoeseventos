package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the V_SAP_DADOS_LIQUIDANTES_SIMPL database table.
 * 
 */
@Entity
@Table(name="V_SAP_DADOS_LIQUIDANTES_SIMPL", schema="CETIP")
@NamedQuery(name="VSapDadosLiquidantesSimpl.findAll", query="SELECT v FROM VSapDadosLiquidantesSimpl v")
public class VSapDadosLiquidantesSimpl implements Serializable {
	@Id
	@Column(name="ID_VIEW")
	private Long idView;
	
	@Column(name="ID_LIQUIDANTE")
	private Long numIdLiquidante;
	
	@Column(name="ID_LIQUIDADO")
	private Long numIdLiquidado;
	
	@Column(name="ID_CONTA_LIQUIDANTE")
	private Long numContaLiquidante;
	
	@Column(name="ID_CONTA_LIQUIDADA")
	private Long numContaLiquidada;

	public Long getIdView() {
		return idView;
	}

	public void setIdView(Long idView) {
		this.idView = idView;
	}

	public Long getNumIdLiquidante() {
		return numIdLiquidante;
	}

	public void setNumIdLiquidante(Long numIdLiquidante) {
		this.numIdLiquidante = numIdLiquidante;
	}

	public Long getNumIdLiquidado() {
		return numIdLiquidado;
	}

	public void setNumIdLiquidado(Long numIdLiquidado) {
		this.numIdLiquidado = numIdLiquidado;
	}

	public Long getNumContaLiquidante() {
		return numContaLiquidante;
	}

	public void setNumContaLiquidante(Long numContaLiquidante) {
		this.numContaLiquidante = numContaLiquidante;
	}

	public Long getNumContaLiquidada() {
		return numContaLiquidada;
	}

	public void setNumContaLiquidada(Long numContaLiquidada) {
		this.numContaLiquidada = numContaLiquidada;
	}

}