package br.com.b3.batch.geraoperacoeseventovcp.state;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_AGUARDANDO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_PROCESSADO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_BT;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_STR;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_SEM;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.PENDENTE_LIQUIDACAO_FINANCEIRA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.PEND_LANC_PU_EVENTO;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class InformarPuState implements OperacaoState{
	private Integer situacaoOperacao;
	private String codCtlProcessamento;
	private static final Logger LOGGER = LoggerFactory.getLogger(InformarPuState.class);
	private static InformarPuState instance = new InformarPuState();
	
	private InformarPuState() {}
	
	public static InformarPuState instance() {
		return instance;
	}
	
	private static final Map<Integer, Integer> map = new HashMap<Integer, Integer>();
	static {
		map.put(MODALIDADE_BRUTA_BT, PEND_LANC_PU_EVENTO);
		map.put(MODALIDADE_BRUTA_STR, PEND_LANC_PU_EVENTO);
		map.put(MODALIDADE_CETIP, PEND_LANC_PU_EVENTO);
		map.put(MODALIDADE_SEM, PEND_LANC_PU_EVENTO);
	}
	
	@Override
	public Integer getSituacaoOperacao() {
		return this.situacaoOperacao;
	}
	
	@Override
	public String getCodCtlProcessamento() {
		return this.codCtlProcessamento;
	}
	
	private void setSituacaoOperacao(Integer situacaoOperacao) {
		this.situacaoOperacao = situacaoOperacao;
		
		setCodCtlProcessamento();
	}
	
	private void setCodCtlProcessamento() {
		this.codCtlProcessamento = COD_CTL_PROCESSAMENTO_PROCESSADO;
		if(PENDENTE_LIQUIDACAO_FINANCEIRA.equals(situacaoOperacao)) {
			this.codCtlProcessamento = COD_CTL_PROCESSAMENTO_AGUARDANDO;
		}
	}
	
	@Override
	public void updateState(SituacaoOperacaoContext context) {
		setSituacaoOperacao(map.get(context.getParameters().getModalidade()));
		
		LOGGER.debug(this + " -> " + context.getCurrent().getSituacaoOperacao() 
				+ " na modalide " + context.getParameters().getModalidade() + " com codCtlProcessamento " + context.getCurrent().getCodCtlProcessamento());
	}
}
