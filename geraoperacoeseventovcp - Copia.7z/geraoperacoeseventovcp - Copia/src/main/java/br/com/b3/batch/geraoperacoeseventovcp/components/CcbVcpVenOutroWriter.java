package br.com.b3.batch.geraoperacoeseventovcp.components;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;
import br.com.b3.batch.geraoperacoeseventovcp.repository.OperacaoRespoitory;

@Component
@StepScope
public class CcbVcpVenOutroWriter implements ItemWriter<Operacao> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CcbVcpVenOutroWriter.class);	
	
	@Autowired
	OperacaoRespoitory repository;
	
	@Override
	public void write(List <? extends Operacao> list) throws Exception {
		LOGGER.debug(this + " -> Gerando total de operações -> " + list.size());
		repository.saveAll(list);
	}
}
