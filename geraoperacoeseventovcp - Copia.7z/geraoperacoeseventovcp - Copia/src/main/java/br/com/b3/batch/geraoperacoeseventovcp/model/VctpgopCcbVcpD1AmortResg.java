package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the VCTPGOP_CCB_VCP_D1_AMORT_RESG database table.
 * 
 */
@Entity
@Table(name="VCTPGOP_CCB_VCP_D1_AMORT_RESG", schema="CETIP")
@NamedQuery(name="VctpgopCcbVcpD1AmortResg.findAll", query="SELECT v FROM VctpgopCcbVcpD1AmortResg v")
public class VctpgopCcbVcpD1AmortResg extends BaseCcbVcp implements Serializable {
	
}