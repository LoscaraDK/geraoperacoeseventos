package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


/**
 * The persistent class for the INSTRUMENTO_FINANCEIRO database table.
 * 
 */
@Entity
@Table(name="INSTRUMENTO_FINANCEIRO", schema="CETIP")
@Inheritance(strategy=InheritanceType.JOINED)
@NamedQuery(name="InstrumentoFinanceiro.findAll", query="SELECT i FROM InstrumentoFinanceiro i")
public class InstrumentoFinanceiro implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NUM_IF")
	private Long numIf;

	@Column(name="COD_IF")
	private String codIf;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_EMISSAO")
	private Date datEmissao;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_EXCLUSAO")
	private Date datExclusao;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_REGISTRO")
	private Date datRegistro;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_VENCIMENTO")
	private Date datVencimento;

	@Column(name="NUM_TIPO_IF")
	private BigDecimal numTipoIf;

	@Column(name="NUM_IF_ORIGEM")
	private Long numIfOrigem;
	
	@Column(name="NUM_ID_FORMA_PAGAMENTO")
	private Integer numIdFormaPagamento;

	public Long getNumIf() {
		return numIf;
	}

	public void setNumIf(Long numIf) {
		this.numIf = numIf;
	}

	public String getCodIf() {
		return codIf;
	}

	public void setCodIf(String codIf) {
		this.codIf = codIf;
	}

	public Date getDatEmissao() {
		return datEmissao;
	}

	public void setDatEmissao(Date datEmissao) {
		this.datEmissao = datEmissao;
	}

	public Date getDatExclusao() {
		return datExclusao;
	}

	public void setDatExclusao(Date datExclusao) {
		this.datExclusao = datExclusao;
	}

	public Date getDatRegistro() {
		return datRegistro;
	}

	public void setDatRegistro(Date datRegistro) {
		this.datRegistro = datRegistro;
	}

	public Date getDatVencimento() {
		return datVencimento;
	}

	public void setDatVencimento(Date datVencimento) {
		this.datVencimento = datVencimento;
	}

	public BigDecimal getNumTipoIf() {
		return numTipoIf;
	}

	public void setNumTipoIf(BigDecimal numTipoIf) {
		this.numTipoIf = numTipoIf;
	}

	public Long getNumIfOrigem() {
		return numIfOrigem;
	}

	public void setNumIfOrigem(Long numIfOrigem) {
		this.numIfOrigem = numIfOrigem;
	}

	public Integer getNumIdFormaPagamento() {
		return numIdFormaPagamento;
	}

	public void setNumIdFormaPagamento(Integer numIdFormaPagamento) {
		this.numIdFormaPagamento = numIdFormaPagamento;
	}

	
}