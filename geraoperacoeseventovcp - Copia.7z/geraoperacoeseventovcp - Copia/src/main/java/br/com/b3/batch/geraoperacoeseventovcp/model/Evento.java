package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the EVENTO database table.
 * 
 */
@Entity
@Table(name="EVENTO", schema="CETIP")
@NamedQuery(name="Evento.findAll", query="SELECT e FROM Evento e")
public class Evento implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NUM_EVENTO")
	private long numEvento;

	@Column(name="COD_ESTADO_REGISTRO")
	private String codEstadoRegistro;

	@Column(name="COD_INDICADOR_FINANCEIRO")
	private BigDecimal codIndicadorFinanceiro;

	@Column(name="COD_MOTIVO_ALTERACAO")
	private String codMotivoAlteracao;

	@Column(name="COD_TIPO_UNIDADE_TEMPO")
	private String codTipoUnidadeTempo;

	@Column(name="COD_TIPO_UNIDADE_TEMPO_APLICA")
	private String codTipoUnidadeTempoAplica;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_ALTERACAO")
	private Date datAlteracao;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_ATUALIZACAO_REGISTRO")
	private Date datAtualizacaoRegistro;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_BARREIRA_CUPOM")
	private Date datBarreiraCupom;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_COTACAO_FIXING")
	private Date datCotacaoFixing;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_COTACAO_FIXING_2")
	private Date datCotacaoFixing2;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_EXCLUSAO")
	private Date datExclusao;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_FATOR_REMUNERADOR")
	private Date datFatorRemunerador;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_INCLUSAO")
	private Date datInclusao;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_INCLUSAO_REGISTRO")
	private Date datInclusaoRegistro;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_LIQUIDACAO")
	private Date datLiquidacao;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_OCORRENCIA_EVENTO")
	private Date datOcorrenciaEvento;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_ORIGINAL_EVENTO")
	private Date datOriginalEvento;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_ULTIMA_ATUALIZACAO_PU")
	private Date datUltimaAtualizacaoPu;

	@Temporal(TemporalType.DATE)
	@Column(name="DATA_FIM_TAXA")
	private Date dataFimTaxa;

	@Temporal(TemporalType.DATE)
	@Column(name="DATA_INICIO_TAXA")
	private Date dataInicioTaxa;

	@Temporal(TemporalType.DATE)
	@Column(name="DATA_OCORRENCIA_LIQUIDACAO")
	private Date dataOcorrenciaLiquidacao;

	@Column(name="IND_CONFIRMACAO_PAGAMENTO")
	private String indConfirmacaoPagamento;

	@Column(name="IND_INCORPORA")
	private String indIncorpora;

	@Column(name="NUM_CONDICAO_IF")
	private BigDecimal numCondicaoIf;

	@Column(name="NUM_ID_AGENTE_CALCULO")
	private BigDecimal numIdAgenteCalculo;

	@Column(name="NUM_ID_ENTIDADE_ATUALIZ")
	private BigDecimal numIdEntidadeAtualiz;

	@Column(name="NUM_ID_ESTADO_EVENTO")
	private Integer numIdEstadoEvento;

	@Column(name="NUM_ID_ESTADO_EVENTO_FINAL")
	private BigDecimal numIdEstadoEventoFinal;

	@Column(name="NUM_ID_HIST_MARCACAO_MERCADO")
	private BigDecimal numIdHistMarcacaoMercado;

	@Column(name="NUM_ID_MARCACAO_MERCADO")
	private BigDecimal numIdMarcacaoMercado;

	@Column(name="NUM_ID_PAPEL_RESP_PU")
	private BigDecimal numIdPapelRespPu;

	@Column(name="NUM_ID_PARAMETRO_PONTA")
	private BigDecimal numIdParametroPonta;

	@Column(name="NUM_ID_TIPO_FIXING")
	private BigDecimal numIdTipoFixing;

	@Column(name="NUM_TIPO_EVENTO_LEGADO")
	private Integer numTipoEventoLegado;

	@Column(name="QTD_DIAS_UTEIS")
	private BigDecimal qtdDiasUteis;

	@Column(name="QTD_EVENTO")
	private BigDecimal qtdEvento;

	@Column(name="RESPONSAVEL_PU")
	private String responsavelPu;

	@Column(name="TXT_OBSERVACAO")
	private String txtObservacao;

	@Column(name="VAL_ALAVANCAGEM_P1")
	private BigDecimal valAlavancagemP1;

	@Column(name="VAL_ALAVANCAGEM_P2")
	private BigDecimal valAlavancagemP2;

	@Column(name="VAL_BARREIRA_CHAMADA")
	private BigDecimal valBarreiraChamada;

	@Column(name="VAL_BARREIRA_CHAMADA_2")
	private BigDecimal valBarreiraChamada2;

	@Column(name="VAL_BARREIRA_CUPOM")
	private BigDecimal valBarreiraCupom;

	@Column(name="VAL_BARREIRA_CUPOM_2")
	private BigDecimal valBarreiraCupom2;

	@Column(name="VAL_CROSS_RATE")
	private BigDecimal valCrossRate;

	@Column(name="VAL_DIFERENCA_AMORTIZACAO")
	private BigDecimal valDiferencaAmortizacao;

	@Column(name="VAL_DIFERENCA_JUROS")
	private BigDecimal valDiferencaJuros;

	@Column(name="VAL_EVENTO")
	private BigDecimal valEvento;

	@Column(name="VAL_FATOR_ATUALIZACAO_NOMINAL")
	private BigDecimal valFatorAtualizacaoNominal;

	@Column(name="VAL_FATOR_JUROS")
	private BigDecimal valFatorJuros;

	@Column(name="VAL_INCORPORACAO_JUROS")
	private BigDecimal valIncorporacaoJuros;

	@Column(name="VAL_LIMITE_INFERIOR")
	private BigDecimal valLimiteInferior;

	@Column(name="VAL_LIMITE_SUPERIOR")
	private BigDecimal valLimiteSuperior;

	@Column(name="VAL_PARIDADE_BASE")
	private BigDecimal valParidadeBase;

	@Column(name="VAL_PARIDADE_COTADA")
	private BigDecimal valParidadeCotada;

	@Column(name="VAL_PERCENTUAL_CURVA")
	private BigDecimal valPercentualCurva;

	@Column(name="VAL_PERCENTUAL_PAGAMENTO")
	private BigDecimal valPercentualPagamento;

	@Column(name="VAL_PU_CALCULADO")
	private BigDecimal valPuCalculado;

	@Column(name="VAL_PU_EVENTO")
	private BigDecimal valPuEvento;

	@Column(name="VAL_PU_EVENTO_FUTURO")
	private BigDecimal valPuEventoFuturo;

	@Column(name="VAL_PU_JUROS_AMORTIZ_FUTURO")
	private BigDecimal valPuJurosAmortizFuturo;

	@Column(name="VAL_PU_JUROS_AMORTIZACAO")
	private BigDecimal valPuJurosAmortizacao;

	@Column(name="VAL_PU_PREMIO_AMORTIZACAO")
	private BigDecimal valPuPremioAmortizacao;

	@Column(name="VAL_REFERENCIA")
	private BigDecimal valReferencia;

	@Column(name="VAL_REFERENCIA_ANTECIPADO")
	private BigDecimal valReferenciaAntecipado;

	@Column(name="VAL_STRIKE")
	private BigDecimal valStrike;

	@Column(name="VAL_TAXA_EVENTO")
	private BigDecimal valTaxaEvento;

	@Column(name="VAL_TAXA_JUROS")
	private BigDecimal valTaxaJuros;

	@Column(name="NUM_IF")
	private Long numIF;

	public Evento() {
	}

	public long getNumEvento() {
		return this.numEvento;
	}

	public void setNumEvento(long numEvento) {
		this.numEvento = numEvento;
	}

	public String getCodEstadoRegistro() {
		return this.codEstadoRegistro;
	}

	public void setCodEstadoRegistro(String codEstadoRegistro) {
		this.codEstadoRegistro = codEstadoRegistro;
	}

	public BigDecimal getCodIndicadorFinanceiro() {
		return this.codIndicadorFinanceiro;
	}

	public void setCodIndicadorFinanceiro(BigDecimal codIndicadorFinanceiro) {
		this.codIndicadorFinanceiro = codIndicadorFinanceiro;
	}

	public String getCodMotivoAlteracao() {
		return this.codMotivoAlteracao;
	}

	public void setCodMotivoAlteracao(String codMotivoAlteracao) {
		this.codMotivoAlteracao = codMotivoAlteracao;
	}

	public String getCodTipoUnidadeTempo() {
		return this.codTipoUnidadeTempo;
	}

	public void setCodTipoUnidadeTempo(String codTipoUnidadeTempo) {
		this.codTipoUnidadeTempo = codTipoUnidadeTempo;
	}

	public String getCodTipoUnidadeTempoAplica() {
		return this.codTipoUnidadeTempoAplica;
	}

	public void setCodTipoUnidadeTempoAplica(String codTipoUnidadeTempoAplica) {
		this.codTipoUnidadeTempoAplica = codTipoUnidadeTempoAplica;
	}

	public Date getDatAlteracao() {
		return this.datAlteracao;
	}

	public void setDatAlteracao(Date datAlteracao) {
		this.datAlteracao = datAlteracao;
	}

	public Date getDatAtualizacaoRegistro() {
		return this.datAtualizacaoRegistro;
	}

	public void setDatAtualizacaoRegistro(Date datAtualizacaoRegistro) {
		this.datAtualizacaoRegistro = datAtualizacaoRegistro;
	}

	public Date getDatBarreiraCupom() {
		return this.datBarreiraCupom;
	}

	public void setDatBarreiraCupom(Date datBarreiraCupom) {
		this.datBarreiraCupom = datBarreiraCupom;
	}

	public Date getDatCotacaoFixing() {
		return this.datCotacaoFixing;
	}

	public void setDatCotacaoFixing(Date datCotacaoFixing) {
		this.datCotacaoFixing = datCotacaoFixing;
	}

	public Date getDatCotacaoFixing2() {
		return this.datCotacaoFixing2;
	}

	public void setDatCotacaoFixing2(Date datCotacaoFixing2) {
		this.datCotacaoFixing2 = datCotacaoFixing2;
	}

	public Date getDatExclusao() {
		return this.datExclusao;
	}

	public void setDatExclusao(Date datExclusao) {
		this.datExclusao = datExclusao;
	}

	public Date getDatFatorRemunerador() {
		return this.datFatorRemunerador;
	}

	public void setDatFatorRemunerador(Date datFatorRemunerador) {
		this.datFatorRemunerador = datFatorRemunerador;
	}

	public Date getDatInclusao() {
		return this.datInclusao;
	}

	public void setDatInclusao(Date datInclusao) {
		this.datInclusao = datInclusao;
	}

	public Date getDatInclusaoRegistro() {
		return this.datInclusaoRegistro;
	}

	public void setDatInclusaoRegistro(Date datInclusaoRegistro) {
		this.datInclusaoRegistro = datInclusaoRegistro;
	}

	public Date getDatLiquidacao() {
		return this.datLiquidacao;
	}

	public void setDatLiquidacao(Date datLiquidacao) {
		this.datLiquidacao = datLiquidacao;
	}

	public Date getDatOcorrenciaEvento() {
		return this.datOcorrenciaEvento;
	}

	public void setDatOcorrenciaEvento(Date datOcorrenciaEvento) {
		this.datOcorrenciaEvento = datOcorrenciaEvento;
	}

	public Date getDatOriginalEvento() {
		return this.datOriginalEvento;
	}

	public void setDatOriginalEvento(Date datOriginalEvento) {
		this.datOriginalEvento = datOriginalEvento;
	}

	public Date getDatUltimaAtualizacaoPu() {
		return this.datUltimaAtualizacaoPu;
	}

	public void setDatUltimaAtualizacaoPu(Date datUltimaAtualizacaoPu) {
		this.datUltimaAtualizacaoPu = datUltimaAtualizacaoPu;
	}

	public Date getDataFimTaxa() {
		return this.dataFimTaxa;
	}

	public void setDataFimTaxa(Date dataFimTaxa) {
		this.dataFimTaxa = dataFimTaxa;
	}

	public Date getDataInicioTaxa() {
		return this.dataInicioTaxa;
	}

	public void setDataInicioTaxa(Date dataInicioTaxa) {
		this.dataInicioTaxa = dataInicioTaxa;
	}

	public Date getDataOcorrenciaLiquidacao() {
		return this.dataOcorrenciaLiquidacao;
	}

	public void setDataOcorrenciaLiquidacao(Date dataOcorrenciaLiquidacao) {
		this.dataOcorrenciaLiquidacao = dataOcorrenciaLiquidacao;
	}

	public String getIndConfirmacaoPagamento() {
		return this.indConfirmacaoPagamento;
	}

	public void setIndConfirmacaoPagamento(String indConfirmacaoPagamento) {
		this.indConfirmacaoPagamento = indConfirmacaoPagamento;
	}

	public String getIndIncorpora() {
		return this.indIncorpora;
	}

	public void setIndIncorpora(String indIncorpora) {
		this.indIncorpora = indIncorpora;
	}

	public BigDecimal getNumCondicaoIf() {
		return this.numCondicaoIf;
	}

	public void setNumCondicaoIf(BigDecimal numCondicaoIf) {
		this.numCondicaoIf = numCondicaoIf;
	}

	public BigDecimal getNumIdAgenteCalculo() {
		return this.numIdAgenteCalculo;
	}

	public void setNumIdAgenteCalculo(BigDecimal numIdAgenteCalculo) {
		this.numIdAgenteCalculo = numIdAgenteCalculo;
	}

	public BigDecimal getNumIdEntidadeAtualiz() {
		return this.numIdEntidadeAtualiz;
	}

	public void setNumIdEntidadeAtualiz(BigDecimal numIdEntidadeAtualiz) {
		this.numIdEntidadeAtualiz = numIdEntidadeAtualiz;
	}

	public Integer getNumIdEstadoEvento() {
		return this.numIdEstadoEvento;
	}

	public void setNumIdEstadoEvento(Integer numIdEstadoEvento) {
		this.numIdEstadoEvento = numIdEstadoEvento;
	}

	public BigDecimal getNumIdEstadoEventoFinal() {
		return this.numIdEstadoEventoFinal;
	}

	public void setNumIdEstadoEventoFinal(BigDecimal numIdEstadoEventoFinal) {
		this.numIdEstadoEventoFinal = numIdEstadoEventoFinal;
	}

	public BigDecimal getNumIdHistMarcacaoMercado() {
		return this.numIdHistMarcacaoMercado;
	}

	public void setNumIdHistMarcacaoMercado(BigDecimal numIdHistMarcacaoMercado) {
		this.numIdHistMarcacaoMercado = numIdHistMarcacaoMercado;
	}

	public BigDecimal getNumIdMarcacaoMercado() {
		return this.numIdMarcacaoMercado;
	}

	public void setNumIdMarcacaoMercado(BigDecimal numIdMarcacaoMercado) {
		this.numIdMarcacaoMercado = numIdMarcacaoMercado;
	}

	public BigDecimal getNumIdPapelRespPu() {
		return this.numIdPapelRespPu;
	}

	public void setNumIdPapelRespPu(BigDecimal numIdPapelRespPu) {
		this.numIdPapelRespPu = numIdPapelRespPu;
	}

	public BigDecimal getNumIdParametroPonta() {
		return this.numIdParametroPonta;
	}

	public void setNumIdParametroPonta(BigDecimal numIdParametroPonta) {
		this.numIdParametroPonta = numIdParametroPonta;
	}

	public BigDecimal getNumIdTipoFixing() {
		return this.numIdTipoFixing;
	}

	public void setNumIdTipoFixing(BigDecimal numIdTipoFixing) {
		this.numIdTipoFixing = numIdTipoFixing;
	}

	public Integer getNumTipoEventoLegado() {
		return this.numTipoEventoLegado;
	}

	public void setNumTipoEventoLegado(Integer numTipoEventoLegado) {
		this.numTipoEventoLegado = numTipoEventoLegado;
	}

	public BigDecimal getQtdDiasUteis() {
		return this.qtdDiasUteis;
	}

	public void setQtdDiasUteis(BigDecimal qtdDiasUteis) {
		this.qtdDiasUteis = qtdDiasUteis;
	}

	public BigDecimal getQtdEvento() {
		return this.qtdEvento;
	}

	public void setQtdEvento(BigDecimal qtdEvento) {
		this.qtdEvento = qtdEvento;
	}

	public String getResponsavelPu() {
		return this.responsavelPu;
	}

	public void setResponsavelPu(String responsavelPu) {
		this.responsavelPu = responsavelPu;
	}

	public String getTxtObservacao() {
		return this.txtObservacao;
	}

	public void setTxtObservacao(String txtObservacao) {
		this.txtObservacao = txtObservacao;
	}

	public BigDecimal getValAlavancagemP1() {
		return this.valAlavancagemP1;
	}

	public void setValAlavancagemP1(BigDecimal valAlavancagemP1) {
		this.valAlavancagemP1 = valAlavancagemP1;
	}

	public BigDecimal getValAlavancagemP2() {
		return this.valAlavancagemP2;
	}

	public void setValAlavancagemP2(BigDecimal valAlavancagemP2) {
		this.valAlavancagemP2 = valAlavancagemP2;
	}

	public BigDecimal getValBarreiraChamada() {
		return this.valBarreiraChamada;
	}

	public void setValBarreiraChamada(BigDecimal valBarreiraChamada) {
		this.valBarreiraChamada = valBarreiraChamada;
	}

	public BigDecimal getValBarreiraChamada2() {
		return this.valBarreiraChamada2;
	}

	public void setValBarreiraChamada2(BigDecimal valBarreiraChamada2) {
		this.valBarreiraChamada2 = valBarreiraChamada2;
	}

	public BigDecimal getValBarreiraCupom() {
		return this.valBarreiraCupom;
	}

	public void setValBarreiraCupom(BigDecimal valBarreiraCupom) {
		this.valBarreiraCupom = valBarreiraCupom;
	}

	public BigDecimal getValBarreiraCupom2() {
		return this.valBarreiraCupom2;
	}

	public void setValBarreiraCupom2(BigDecimal valBarreiraCupom2) {
		this.valBarreiraCupom2 = valBarreiraCupom2;
	}

	public BigDecimal getValCrossRate() {
		return this.valCrossRate;
	}

	public void setValCrossRate(BigDecimal valCrossRate) {
		this.valCrossRate = valCrossRate;
	}

	public BigDecimal getValDiferencaAmortizacao() {
		return this.valDiferencaAmortizacao;
	}

	public void setValDiferencaAmortizacao(BigDecimal valDiferencaAmortizacao) {
		this.valDiferencaAmortizacao = valDiferencaAmortizacao;
	}

	public BigDecimal getValDiferencaJuros() {
		return this.valDiferencaJuros;
	}

	public void setValDiferencaJuros(BigDecimal valDiferencaJuros) {
		this.valDiferencaJuros = valDiferencaJuros;
	}

	public BigDecimal getValEvento() {
		return this.valEvento;
	}

	public void setValEvento(BigDecimal valEvento) {
		this.valEvento = valEvento;
	}

	public BigDecimal getValFatorAtualizacaoNominal() {
		return this.valFatorAtualizacaoNominal;
	}

	public void setValFatorAtualizacaoNominal(BigDecimal valFatorAtualizacaoNominal) {
		this.valFatorAtualizacaoNominal = valFatorAtualizacaoNominal;
	}

	public BigDecimal getValFatorJuros() {
		return this.valFatorJuros;
	}

	public void setValFatorJuros(BigDecimal valFatorJuros) {
		this.valFatorJuros = valFatorJuros;
	}

	public BigDecimal getValIncorporacaoJuros() {
		return this.valIncorporacaoJuros;
	}

	public void setValIncorporacaoJuros(BigDecimal valIncorporacaoJuros) {
		this.valIncorporacaoJuros = valIncorporacaoJuros;
	}

	public BigDecimal getValLimiteInferior() {
		return this.valLimiteInferior;
	}

	public void setValLimiteInferior(BigDecimal valLimiteInferior) {
		this.valLimiteInferior = valLimiteInferior;
	}

	public BigDecimal getValLimiteSuperior() {
		return this.valLimiteSuperior;
	}

	public void setValLimiteSuperior(BigDecimal valLimiteSuperior) {
		this.valLimiteSuperior = valLimiteSuperior;
	}

	public BigDecimal getValParidadeBase() {
		return this.valParidadeBase;
	}

	public void setValParidadeBase(BigDecimal valParidadeBase) {
		this.valParidadeBase = valParidadeBase;
	}

	public BigDecimal getValParidadeCotada() {
		return this.valParidadeCotada;
	}

	public void setValParidadeCotada(BigDecimal valParidadeCotada) {
		this.valParidadeCotada = valParidadeCotada;
	}

	public BigDecimal getValPercentualCurva() {
		return this.valPercentualCurva;
	}

	public void setValPercentualCurva(BigDecimal valPercentualCurva) {
		this.valPercentualCurva = valPercentualCurva;
	}

	public BigDecimal getValPercentualPagamento() {
		return this.valPercentualPagamento;
	}

	public void setValPercentualPagamento(BigDecimal valPercentualPagamento) {
		this.valPercentualPagamento = valPercentualPagamento;
	}

	public BigDecimal getValPuCalculado() {
		return this.valPuCalculado;
	}

	public void setValPuCalculado(BigDecimal valPuCalculado) {
		this.valPuCalculado = valPuCalculado;
	}

	public BigDecimal getValPuEvento() {
		return this.valPuEvento;
	}

	public void setValPuEvento(BigDecimal valPuEvento) {
		this.valPuEvento = valPuEvento;
	}

	public BigDecimal getValPuEventoFuturo() {
		return this.valPuEventoFuturo;
	}

	public void setValPuEventoFuturo(BigDecimal valPuEventoFuturo) {
		this.valPuEventoFuturo = valPuEventoFuturo;
	}

	public BigDecimal getValPuJurosAmortizFuturo() {
		return this.valPuJurosAmortizFuturo;
	}

	public void setValPuJurosAmortizFuturo(BigDecimal valPuJurosAmortizFuturo) {
		this.valPuJurosAmortizFuturo = valPuJurosAmortizFuturo;
	}

	public BigDecimal getValPuJurosAmortizacao() {
		return this.valPuJurosAmortizacao;
	}

	public void setValPuJurosAmortizacao(BigDecimal valPuJurosAmortizacao) {
		this.valPuJurosAmortizacao = valPuJurosAmortizacao;
	}

	public BigDecimal getValPuPremioAmortizacao() {
		return this.valPuPremioAmortizacao;
	}

	public void setValPuPremioAmortizacao(BigDecimal valPuPremioAmortizacao) {
		this.valPuPremioAmortizacao = valPuPremioAmortizacao;
	}

	public BigDecimal getValReferencia() {
		return this.valReferencia;
	}

	public void setValReferencia(BigDecimal valReferencia) {
		this.valReferencia = valReferencia;
	}

	public BigDecimal getValReferenciaAntecipado() {
		return this.valReferenciaAntecipado;
	}

	public void setValReferenciaAntecipado(BigDecimal valReferenciaAntecipado) {
		this.valReferenciaAntecipado = valReferenciaAntecipado;
	}

	public BigDecimal getValStrike() {
		return this.valStrike;
	}

	public void setValStrike(BigDecimal valStrike) {
		this.valStrike = valStrike;
	}

	public BigDecimal getValTaxaEvento() {
		return this.valTaxaEvento;
	}

	public void setValTaxaEvento(BigDecimal valTaxaEvento) {
		this.valTaxaEvento = valTaxaEvento;
	}

	public BigDecimal getValTaxaJuros() {
		return this.valTaxaJuros;
	}

	public void setValTaxaJuros(BigDecimal valTaxaJuros) {
		this.valTaxaJuros = valTaxaJuros;
	}

	public Long getNumIF() {
		return numIF;
	}

	public void setNumIF(Long numIF) {
		this.numIF = numIF;
	}

}