package br.com.b3.batch.geraoperacoeseventovcp.state;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_PROCESSADO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.FINALIZADA;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FinalizadoState implements OperacaoState{
	private static FinalizadoState instance = new FinalizadoState();
	private static final Logger LOGGER = LoggerFactory.getLogger(FinalizadoState.class);
	private FinalizadoState() {}
	
	public static FinalizadoState instance() {
		return instance;
	}
	
	@Override
	public String getCodCtlProcessamento() {
		return COD_CTL_PROCESSAMENTO_PROCESSADO;
	}
	
	@Override
	public Integer getSituacaoOperacao() {
		return FINALIZADA;
	}

	@Override
	public void updateState(SituacaoOperacaoContext context) {
		LOGGER.debug(this + " -> " + context.getCurrent().getSituacaoOperacao() + " na modalide " + context.getParameters().getModalidade());
	}
}
