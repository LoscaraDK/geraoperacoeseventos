package br.com.b3.batch.geraoperacoeseventovcp.components;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;
import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpVenOutro;
import br.com.b3.batch.geraoperacoeseventovcp.tradutor.Transform;

@Component (value = "ccbVcpVenOutroProcessor")
public class CcbVcpVenOutroProcessor implements ItemProcessor<VctpgopCcbVcpVenOutro, Operacao> {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CcbVcpVenOutroProcessor.class);
	
	@Autowired
	private Transform transform;
	
	@Override
	public Operacao process(VctpgopCcbVcpVenOutro evento) throws Exception {
		LOGGER.debug("Evento id = " + evento.getEvento());
		
		Operacao operacao = transform.process(evento);
		
		return operacao;
	}
	
}
