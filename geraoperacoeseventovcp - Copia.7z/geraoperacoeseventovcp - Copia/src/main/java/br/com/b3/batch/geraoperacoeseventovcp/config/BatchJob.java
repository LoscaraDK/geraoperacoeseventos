package br.com.b3.batch.geraoperacoeseventovcp.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;

import br.com.b3.batch.geraoperacoeseventovcp.listener.EventoJobExecutionListener;

@EnableBatchProcessing
@Configuration
public class BatchJob {
	private static final Logger LOGGER = LoggerFactory.getLogger(BatchJob.class);	
	
	@Autowired
	private JobBuilderFactory jobBuilderFactory;

	@Autowired
	@Qualifier(value="flowCcbVcpD1AmortResg")
	private Flow flowCcbVcpD1AmortResg;
	
	@Autowired
	@Qualifier(value="flowCcbVcpD1JurosRend")
	private Flow flowCcbVcpD1JurosRend;
	
	@Autowired
	@Qualifier(value="flowCcbVcpD1Outro")
	private Flow flowCcbVcpD1Outro;
	
	@Autowired
	@Qualifier(value="flowCcbVcpVenAmortResg")
	private Flow flowCcbVcpVenAmortResg;
	
	@Autowired
	@Qualifier(value="flowCcbVcpVenJurosRend")
	private Flow flowCcbVcpVenJurosRend;
	
	@Autowired
	@Qualifier(value="flowCcbVcpVenOutro")
	private Flow flowCcbVcpVenOutro;
	
	@Autowired
	private EventoJobExecutionListener eventoJobExecutionListener;
	
	@Bean(name="jobSGeraOpersVCP")
	public Job job() throws Exception{
		return jobBuilderFactory.get("jobGeraOpersVCP")
				.listener(eventoJobExecutionListener)
				.incrementer(new RunIdIncrementer())
				.start(splitFlow())
				.build() //build flowbuilder instance
				.build(); //build job instance
	}

	/**
	 * Utilizado para disparar dois steps em paralelo
	 * @return
	 * @throws Exception
	 */
	@Bean
	public Flow splitFlow() throws Exception{
		return new FlowBuilder<SimpleFlow>("splitFlow")
				.split(new SimpleAsyncTaskExecutor("splitFlowTaskExecutor"))
				.add(flowCcbVcpD1AmortResg, 
					 flowCcbVcpD1JurosRend, 
					 flowCcbVcpD1Outro,
					 flowCcbVcpVenAmortResg,
					 flowCcbVcpVenJurosRend,
					 flowCcbVcpVenOutro
					 )
				.build();
	}
	
	
}