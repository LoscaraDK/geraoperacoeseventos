package br.com.b3.batch.geraoperacoeseventovcp.tradutor;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_BILATERAL;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_BRUTA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.GRP_MODALIDADE_SEM;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BILATERAL_STR;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_BT;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_SEM;

import java.util.HashMap;
import java.util.Map;

public class TradutorModalidade {
	private static final TradutorModalidade instance = new TradutorModalidade();
	
	public static TradutorModalidade instance() {
		return instance;
	}
	
	private TradutorModalidade() {}
	
	private static final Map<Integer,Integer> modalidadesPadrao;
	static {
		modalidadesPadrao = new HashMap<Integer,Integer>();
		modalidadesPadrao.put(GRP_MODALIDADE_CETIP, MODALIDADE_CETIP);
		modalidadesPadrao.put(GRP_MODALIDADE_BRUTA, MODALIDADE_BRUTA_BT);
		modalidadesPadrao.put(GRP_MODALIDADE_SEM, MODALIDADE_SEM);
		modalidadesPadrao.put(GRP_MODALIDADE_BILATERAL, MODALIDADE_BILATERAL_STR);
		
	}
	
	public Integer traduzModalidadePadrao(Integer grpModalidade) {
		return modalidadesPadrao.get(grpModalidade);
	}
}
