package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/**
 * The persistent class for the CONTA_PARTICIPANTE database table.
 * 
 */
@Entity
@Table(name="CONTA_PARTICIPANTE", schema="CETIP")
@NamedQuery(name="ContaParticipante.findAll", query="SELECT c FROM ContaParticipante c")
public class ContaParticipante implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NUM_CONTA_PARTICIPANTE")
	private Long numContaParticipante;

	@Column(name="COD_CONTA_PARTICIPANTE")
	private String codContaParticipante;
	
	@Column(name="NOM_CONTA_PARTICIPANTE")
	private String nomContaParticipante;

	@Column(name="NUM_ID_TIPO_CONTA")
	private Integer numIdTipoConta;
	
	@Column(name="NUM_ID_ENTIDADE")
	private Long numIdEntidade;
	
	@Column(name="NUM_ID_MALOTE")
	private Long numIdMalote;

	@Column(name="NUM_ID_SITUACAO_CONTA")
	private Integer numIdSituacaoConta;
	
	@Column(name="DES_MOTIVO_SITUACAO_CONTA")
	private String desMotivoSituacaoConta;
	
	@Column(name="IND_BLOQUEIO_ACESSO")
	private String indBloqueioAcesso;

	@Column(name="IND_EXCLUIDO")
	private String indExcluido;

	@Column(name="IND_INADIMPLENTE")
	private String indInadimplente;

	@Column(name="NUM_ID_ENTIDADE_ATUALIZ")
	private Long numIdEntidadeAtualiz;

	@Column(name="TXT_OBSERVACOES")
	private String txtObservacoes;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DAT_ENCERRAMENTO")
	private Date datEncerramento;

	@Temporal(TemporalType.DATE)
	@Column(name="DAT_INCLUSAO")
	private Date datInclusao;

	public Long getNumContaParticipante() {
		return numContaParticipante;
	}

	public void setNumContaParticipante(Long numContaParticipante) {
		this.numContaParticipante = numContaParticipante;
	}

	public String getCodContaParticipante() {
		return codContaParticipante;
	}

	public void setCodContaParticipante(String codContaParticipante) {
		this.codContaParticipante = codContaParticipante;
	}

	public String getNomContaParticipante() {
		return nomContaParticipante;
	}

	public void setNomContaParticipante(String nomContaParticipante) {
		this.nomContaParticipante = nomContaParticipante;
	}

	public Integer getNumIdTipoConta() {
		return numIdTipoConta;
	}

	public void setNumIdTipoConta(Integer numIdTipoConta) {
		this.numIdTipoConta = numIdTipoConta;
	}

	public Long getNumIdEntidade() {
		return numIdEntidade;
	}

	public void setNumIdEntidade(Long numIdEntidade) {
		this.numIdEntidade = numIdEntidade;
	}

	public Long getNumIdMalote() {
		return numIdMalote;
	}

	public void setNumIdMalote(Long numIdMalote) {
		this.numIdMalote = numIdMalote;
	}

	public Integer getNumIdSituacaoConta() {
		return numIdSituacaoConta;
	}

	public void setNumIdSituacaoConta(Integer numIdSituacaoConta) {
		this.numIdSituacaoConta = numIdSituacaoConta;
	}

	public String getDesMotivoSituacaoConta() {
		return desMotivoSituacaoConta;
	}

	public void setDesMotivoSituacaoConta(String desMotivoSituacaoConta) {
		this.desMotivoSituacaoConta = desMotivoSituacaoConta;
	}

	public String getIndBloqueioAcesso() {
		return indBloqueioAcesso;
	}

	public void setIndBloqueioAcesso(String indBloqueioAcesso) {
		this.indBloqueioAcesso = indBloqueioAcesso;
	}

	public String getIndExcluido() {
		return indExcluido;
	}

	public void setIndExcluido(String indExcluido) {
		this.indExcluido = indExcluido;
	}

	public String getIndInadimplente() {
		return indInadimplente;
	}

	public void setIndInadimplente(String indInadimplente) {
		this.indInadimplente = indInadimplente;
	}

	public Long getNumIdEntidadeAtualiz() {
		return numIdEntidadeAtualiz;
	}

	public void setNumIdEntidadeAtualiz(Long numIdEntidadeAtualiz) {
		this.numIdEntidadeAtualiz = numIdEntidadeAtualiz;
	}

	public String getTxtObservacoes() {
		return txtObservacoes;
	}

	public void setTxtObservacoes(String txtObservacoes) {
		this.txtObservacoes = txtObservacoes;
	}

	public Date getDatEncerramento() {
		return datEncerramento;
	}

	public void setDatEncerramento(Date datEncerramento) {
		this.datEncerramento = datEncerramento;
	}

	public Date getDatInclusao() {
		return datInclusao;
	}

	public void setDatInclusao(Date datInclusao) {
		this.datInclusao = datInclusao;
	}
}