package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.CCB_LIQUIDACAO_FORA_AMBITO_B3;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_COOBRIGACAO_INTEGRAL;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_COOBRIGACAO_PARCIAL;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_COOBRIGACAO_SEM_COOBRIGACAO;

import java.util.HashMap;
import java.util.Map;

public class FactoryEstrategySelector {
	private static final Map<Integer, String> mapaEstrategias;
	
	private FactoryEstrategySelector() {}
		
	static {
		mapaEstrategias = new HashMap<Integer, String>();
		mapaEstrategias.put(new StrategySelector(COD_COOBRIGACAO_INTEGRAL, null).hashCode(), "br.com.b3.batch.geraoperacoeseventovcp.modalidade.ModalidadeCoobrigacaoIntegral");
		mapaEstrategias.put(new StrategySelector(COD_COOBRIGACAO_PARCIAL, null).hashCode(), "br.com.b3.batch.geraoperacoeseventovcp.modalidade.ModalidadeSemCoobrigacaoOuParcial");
		mapaEstrategias.put(new StrategySelector(COD_COOBRIGACAO_SEM_COOBRIGACAO, null).hashCode(), "br.com.b3.batch.geraoperacoeseventovcp.modalidade.ModalidadeSemCoobrigacaoOuParcial");
		mapaEstrategias.put(new StrategySelector(COD_COOBRIGACAO_SEM_COOBRIGACAO, CCB_LIQUIDACAO_FORA_AMBITO_B3).hashCode(), "br.com.b3.batch.geraoperacoeseventovcp.modalidade.ModalidadePorPgtoForaAmbito");
	}
	
	public static final FactoryEstrategySelector instance() {
		return new FactoryEstrategySelector();
	}
	
	public ModalidadeStrategy getStrategy(StrategySelector selector){
		try {
			return (ModalidadeStrategy) Class.forName(mapaEstrategias.get(selector.hashCode())).newInstance();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		return null;
	}
}
