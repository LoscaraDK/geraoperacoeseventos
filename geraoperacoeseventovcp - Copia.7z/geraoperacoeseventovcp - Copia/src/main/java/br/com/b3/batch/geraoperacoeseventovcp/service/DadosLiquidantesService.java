package br.com.b3.batch.geraoperacoeseventovcp.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import br.com.b3.batch.geraoperacoeseventovcp.model.VSapDadosLiquidantesSimpl;
import br.com.b3.batch.geraoperacoeseventovcp.repository.VSapDadosLiquidantesSimplRepository;

@Service("dadosLiquidantesService")
public class DadosLiquidantesService {
	private static final Logger LOGGER = LoggerFactory.getLogger(DadosLiquidantesService.class);
	
	@Autowired
	VSapDadosLiquidantesSimplRepository repository;
	
	@Cacheable(key = "#numContaLiquidada", value = "numIdLiquidante", unless="#result == null" )
	public Long carregarNumIdLiquidante(Long numContaLiquidada) {
		VSapDadosLiquidantesSimpl resultado = repository.findByNumContaLiquidada(numContaLiquidada);
		
		if (resultado != null && (resultado.getNumContaLiquidante() != null && resultado.getNumIdLiquidante() > 0)){
			
			return resultado.getNumIdLiquidante();
		} 
			
		return null;
	}
}
