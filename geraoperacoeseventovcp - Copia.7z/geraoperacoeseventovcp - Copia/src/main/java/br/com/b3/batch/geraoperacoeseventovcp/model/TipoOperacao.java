package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;


/**
 * The persistent class for the TIPO_OPERACAO database table.
 * 
 */
@Entity
@Table(name="TIPO_OPERACAO")
@NamedQuery(name="TipoOperacao.findAll", query="SELECT t FROM TipoOperacao t")
public class TipoOperacao implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NUM_ID_TIPO_OPERACAO")
	private Long numIdTipoOperacao;

	@Column(name="COD_TIPO_OPERACAO")
	private Integer codTipoOperacao;

	@Column(name="NOM_TIPO_OPERACAO")
	private String nomTipoOperacao;

	//bi-directional many-to-one association to TipoOperObjetoServ
	@OneToMany(mappedBy="tipoOperacao")
	private List<TipoOperObjetoServ> tipoOperObjetoServs;

	public Long getNumIdTipoOperacao() {
		return this.numIdTipoOperacao;
	}

	public void setNumIdTipoOperacao(Long numIdTipoOperacao) {
		this.numIdTipoOperacao = numIdTipoOperacao;
	}

	public Integer getCodTipoOperacao() {
		return this.codTipoOperacao;
	}

	public void setCodTipoOperacao(Integer codTipoOperacao) {
		this.codTipoOperacao = codTipoOperacao;
	}

	public String getNomTipoOperacao() {
		return this.nomTipoOperacao;
	}

	public void setNomTipoOperacao(String nomTipoOperacao) {
		this.nomTipoOperacao = nomTipoOperacao;
	}

	public List<TipoOperObjetoServ> getTipoOperObjetoServs() {
		return this.tipoOperObjetoServs;
	}

	public void setTipoOperObjetoServs(List<TipoOperObjetoServ> tipoOperObjetoServs) {
		this.tipoOperObjetoServs = tipoOperObjetoServs;
	}

	public TipoOperObjetoServ addTipoOperObjetoServ(TipoOperObjetoServ tipoOperObjetoServ) {
		getTipoOperObjetoServs().add(tipoOperObjetoServ);
		tipoOperObjetoServ.setTipoOperacao(this);

		return tipoOperObjetoServ;
	}

	public TipoOperObjetoServ removeTipoOperObjetoServ(TipoOperObjetoServ tipoOperObjetoServ) {
		getTipoOperObjetoServs().remove(tipoOperObjetoServ);
		tipoOperObjetoServ.setTipoOperacao(null);

		return tipoOperObjetoServ;
	}

}