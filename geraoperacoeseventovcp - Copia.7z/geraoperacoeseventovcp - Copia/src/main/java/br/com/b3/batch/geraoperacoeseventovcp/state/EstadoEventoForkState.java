package br.com.b3.batch.geraoperacoeseventovcp.state;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.*;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.b3.batch.geraoperacoeseventovcp.exceptions.EstadoEventoNaoMapeadoException;

public class EstadoEventoForkState implements OperacaoState{
	private static final Logger LOGGER = LoggerFactory.getLogger(EstadoEventoForkState.class);
	private static EstadoEventoForkState instance = new EstadoEventoForkState();
	
	private EstadoEventoForkState() {}
	
	public static EstadoEventoForkState instance() {
		return instance;
	}
	
	@Override
	public String getCodCtlProcessamento() {
		return COD_CTL_PROCESSAMENTO_PROCESSADO;
	}
	
	@Override
	public Integer getSituacaoOperacao() {
		return PEND_INT_CONFIRMACAO_SALDO;
	}
	
	@Override
	public void updateState(SituacaoOperacaoContext context) throws Exception {
		LOGGER.debug(this + " -> " + context.getCurrent().getSituacaoOperacao());
		LOGGER.debug(this + " numIdEstadoEvento -> " + context.getParameters().getEstadoEvento());
		Integer numIdEstadoEvento = context.getParameters().getEstadoEvento();
		
		OperacaoState state = OperacaoStateFactory.instance().getState(numIdEstadoEvento);
		
		if(state == null) {
			throw new EstadoEventoNaoMapeadoException("Estado evento não mapeado [" + numIdEstadoEvento +"]");
		}
		
		context.setCurrent(state);
		context.next();
	}
}
