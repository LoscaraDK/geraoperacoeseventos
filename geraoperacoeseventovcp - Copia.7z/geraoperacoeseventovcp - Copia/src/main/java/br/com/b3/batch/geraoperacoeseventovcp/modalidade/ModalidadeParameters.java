package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

import java.math.BigDecimal;

public class ModalidadeParameters {
	private Integer numIdEstadoEvento;
	private Integer numIdFormaPagamento;
	private Integer numTipoEventoLegado;
	private Long numContaP1;
	private String codContaP1;
	private Long numContaP2;
	private String codContaP2;
	private Long numEntidadeLiquidanteP1;
	private Long numEntidadeLiquidanteP2;
	private Long numEntidadeContaP1;
	private Long numEntidadeContaP2;
	private String codCoobrigacao;
	private String indConfirmacaoPagamento;
	private BigDecimal valPercentualPagamento;
	private BigDecimal valFinanceiro;
	private String indEventosCursadosCetip;
	private String indVencidoInadimplido;
	
	private ModalidadeParameters(ModalidadeParametersBuilder builder) {
		this.numIdEstadoEvento = builder.numIdEstadoEvento;
		this.numIdFormaPagamento = builder.numIdFormaPagamento;
		this.numTipoEventoLegado = builder.numTipoEventoLegado;
		this.numContaP1 = builder.numContaP1;
		this.numContaP2 = builder.numContaP2;
		this.codContaP1 = builder.codContaP1;
		this.codContaP2 = builder.codContaP2;
		this.numEntidadeLiquidanteP1 = builder.numEntidadeLiquidanteP1;
		this.numEntidadeLiquidanteP2 = builder.numEntidadeLiquidanteP2;
		this.numEntidadeContaP1 = builder.numEntidadeContaP1;
		this.numEntidadeContaP2 = builder.numEntidadeContaP2;
		this.codCoobrigacao = builder.codCoobrigacao;
		this.indConfirmacaoPagamento = builder.indConfirmacaoPagamento;
		this.valPercentualPagamento = builder.valPercentualPagamento;
		this.valFinanceiro = builder.valFinanceiro;
		this.indEventosCursadosCetip = builder.indEventosCursadosCetip;
		this.indVencidoInadimplido = builder.indVencidoInadimplido;
	}

	public Integer getEstadoEvento() {
		return this.numIdEstadoEvento;
	}
	public Integer getNumIdFormaPagamento() {
		return this.numIdFormaPagamento;
	}
	public Integer getNumTipoEvento() {
		return this.numTipoEventoLegado;
	}
	public Long getNumContaP1() {
		return this.numContaP1;
	}
	public Long getNumContaP2() {
		return this.numContaP2;
	}
	public String getCodContaP1() {
		return this.codContaP1;
	}
	public String getTipoCodContaP1() {
		return this.codContaP1.substring(6, 8);
	}
	public String getTipoCodContaP2() {
		return this.codContaP2.substring(6, 8);
	}
	public String getCodContaP2() {
		return this.codContaP2;
	}
	public String getCodCoobrigacao() {
		return this.codCoobrigacao;
	}
	public Long getNumEntidadeLiquidanteP1() {
		return this.numEntidadeLiquidanteP1;
	}
	public Long getNumEntidadeLiquidanteP2() {
		return this.numEntidadeLiquidanteP2;
	}
	public Long getNumEntidadeContaP1() {
		return this.numEntidadeContaP1;
	}
	public Long getNumEntidadeContaP2() {
		return this.numEntidadeContaP2;
	}
	public String getIndConfirmacaoPagamento() {
		return this.indConfirmacaoPagamento;
	}
	public BigDecimal getValPercentualPagamento() {
		return this.valPercentualPagamento;
	}
	public BigDecimal getValorFinanceiro() {
		return this.valFinanceiro;
	}
	public String getIndEventosCursadosCetip() {
		return this.indEventosCursadosCetip;
	}
	public String getIndVencidoInadimplido() {
		return this.indVencidoInadimplido;
	}

	public static class ModalidadeParametersBuilder {
		private Integer numIdEstadoEvento;
		private Integer numIdFormaPagamento;
		private Integer numTipoEventoLegado;
		private Long numContaP1;
		private String codContaP1;
		private Long numContaP2;
		private String codContaP2;
		private Long numEntidadeLiquidanteP1;
		private Long numEntidadeLiquidanteP2;
		private Long numEntidadeContaP1;
		private Long numEntidadeContaP2;
		private String codCoobrigacao;
		private String indConfirmacaoPagamento;
		private BigDecimal valPercentualPagamento;
		private BigDecimal valFinanceiro;
		private String indEventosCursadosCetip;
		private String indVencidoInadimplido;
		
		public ModalidadeParametersBuilder addEstadoEvento(Integer numIdEstadoEvento) {
			this.numIdEstadoEvento = numIdEstadoEvento;
			return this;
		}
		public ModalidadeParametersBuilder addNumIdFormaPagamento(Integer numIdFormaPagamento) {
			this.numIdFormaPagamento = numIdFormaPagamento;
			return this;
		}
		public ModalidadeParametersBuilder addNumTipoEventoLegado(Integer numTipoEventoLegado) {
			this.numTipoEventoLegado = numTipoEventoLegado;
			return this;
		}
		public ModalidadeParametersBuilder addNumContaP1(Long numContaP1) {
			this.numContaP1 = numContaP1;
			return this;
		}
		public ModalidadeParametersBuilder addNumContaP2(Long numContaP2) {
			this.numContaP2 = numContaP2;
			return this;
		}
		public ModalidadeParametersBuilder addCodContaP1(String codContaP1) {
			this.codContaP1 = codContaP1;
			return this;
		}
		public ModalidadeParametersBuilder addCodContaP2(String codContaP2) {
			this.codContaP2 = codContaP2;
			return this;
		}
		public ModalidadeParametersBuilder addNumEntidadeLiquidanteP1(Long numEntidadeLiquidanteP1) {
			this.numEntidadeLiquidanteP1 = numEntidadeLiquidanteP1;
			return this;
		}
		public ModalidadeParametersBuilder addNumEntidadeLiquidanteP2(Long numEntidadeLiquidanteP2) {
			this.numEntidadeLiquidanteP2 = numEntidadeLiquidanteP2;
			return this;
		}
		public ModalidadeParametersBuilder addNumEntidadeContaP1(Long numEntidadeContaP1) {
			this.numEntidadeContaP1 = numEntidadeContaP1;
			return this;
		}
		public ModalidadeParametersBuilder addNumEntidadeContaP2(Long numEntidadeContaP2) {
			this.numEntidadeContaP2 = numEntidadeContaP2;
			return this;
		}
		public ModalidadeParametersBuilder addCodCoobrigacao(String codCoobrigacao) {
			this.codCoobrigacao = codCoobrigacao;
			return this;
		}
		public ModalidadeParametersBuilder addIndConfirmacaoPagamento(String indConfirmacaoPagamento) {
			this.indConfirmacaoPagamento = indConfirmacaoPagamento;
			return this;
		}
		public ModalidadeParametersBuilder addPercentualPagamento(BigDecimal valPercentualPagamento) {
			this.valPercentualPagamento = valPercentualPagamento;
			return this;
		}
		public ModalidadeParametersBuilder addValorFinanceiro(BigDecimal valFinanceiro) {
			this.valFinanceiro = valFinanceiro;
			return this;
		}
		public ModalidadeParametersBuilder addIndEventosCursadosCetip(String indEventosCursadosCetip) {
			this.indEventosCursadosCetip = indEventosCursadosCetip;
			return this;
		}
		public ModalidadeParametersBuilder addIndVencidoInadimplido(String indVencidoInadimplido) {
			this.indVencidoInadimplido = indVencidoInadimplido;
			return this;
		}
		
		public ModalidadeParameters build() {
			return new ModalidadeParameters(this);
		}
	}
}
