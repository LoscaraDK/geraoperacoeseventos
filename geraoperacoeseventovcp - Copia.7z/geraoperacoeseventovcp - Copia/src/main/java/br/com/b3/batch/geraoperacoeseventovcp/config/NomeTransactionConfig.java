package br.com.b3.batch.geraoperacoeseventovcp.config;

import java.util.Collections;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaRepositories(entityManagerFactoryRef = "nomeEntityManagerFactory", transactionManagerRef = "nomeTransactionManager", basePackages = {
		"br.com.b3.batch.geraoperacoeseventovcp.repository" })
@EnableTransactionManagement
public class NomeTransactionConfig {
	@Bean(name = "nome-datasource")
	@ConfigurationProperties(prefix = "spring.datasource")
	public DataSource criarDatasourceNome() {
		return DataSourceBuilder.create().build();
	}
	@Bean(name = "nomeEntityManagerFactory")
	public LocalContainerEntityManagerFactoryBean nomeEntityManagerFactory(EntityManagerFactoryBuilder builder,
			@Qualifier("nome-datasource") DataSource datasource) {
		return builder.dataSource(datasource).packages("br.com.b3.batch.geraoperacoeseventovcp.model")
				.persistenceUnit("nomePersistence")
				.properties(Collections.singletonMap("hibernate.dialect", "org.hibernate.dialect.Oracle10gDialect"))
				.build();
	}
	@Bean(name = "nomeTransactionManager")
	public PlatformTransactionManager nomeTransactionManager(
			@Qualifier("nomeEntityManagerFactory") EntityManagerFactory emFactory) {
		return new JpaTransactionManager(emFactory);
	}
}