package br.com.b3.batch.geraoperacoeseventovcp.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.batch.core.partition.support.Partitioner;
import org.springframework.batch.item.ExecutionContext;

public class EventosPartitioner implements Partitioner {
	private int totalLinhas;

	public void setTotalLinhas(int totalLinhas) {
		this.totalLinhas = totalLinhas;
	}

	@Override
	public Map<String, ExecutionContext> partition(int gridSize) {
		int min = 1;
		int max = totalLinhas;

		int targetSize = (max - min) / gridSize + 1;
		
		Map<String, ExecutionContext> result = new HashMap<String, ExecutionContext>();

		int contador = 0;
		int start = min;
		int end = start + targetSize - 1;

		while (start <= max) {
			ExecutionContext value = new ExecutionContext();
			result.put("partition" + contador, value);

			if (end >= max) {
				end = max;
			}

			value.putInt("minValue", start);
			value.putInt("maxValue", end);
			
			start += targetSize;
			end += targetSize;

			contador++;
		}

		return result;
	}
}
