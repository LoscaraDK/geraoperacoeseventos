package br.com.b3.batch.geraoperacoeseventovcp.mapper;

public interface CodigoMap {
	public void seleciona(SelecionaMapContext selecionaMapContext);
	public Integer getCodigoTipoOperacao();
}
