package br.com.b3.batch.geraoperacoeseventovcp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpD1AmortResg;

@Repository
public interface CcbVcpD1AmortResgRepository extends JpaRepository<VctpgopCcbVcpD1AmortResg, Long> {
	
}


