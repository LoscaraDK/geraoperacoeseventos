package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.Table;


/**
 * The persistent class for the TIPO_OPER_OBJETO_SERV database table.
 * 
 */
@Entity
@Table(name="TIPO_OPER_OBJETO_SERV")
@NamedQuery(name="TipoOperObjetoServ.findAll", query="SELECT t FROM TipoOperObjetoServ t")
public class TipoOperObjetoServ implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="NUM_ID_TIPO_OPER_OBJETO_SERV")
	private Integer numIdTipoOperObjetoServ;

	@Column(name="NUM_ID_OBJETO_SERVICO")
	private Integer numIdObjetoServico;

	@ManyToOne
	@JoinColumn(name="NUM_ID_TIPO_OPERACAO")
	private TipoOperacao tipoOperacao;

	public Integer getNumIdTipoOperObjetoServ() {
		return this.numIdTipoOperObjetoServ;
	}

	public void setNumIdTipoOperObjetoServ(Integer numIdTipoOperObjetoServ) {
		this.numIdTipoOperObjetoServ = numIdTipoOperObjetoServ;
	}

	public Integer getNumIdObjetoServico() {
		return this.numIdObjetoServico;
	}

	public void setNumIdObjetoServico(Integer numIdObjetoServico) {
		this.numIdObjetoServico = numIdObjetoServico;
	}

	public TipoOperacao getTipoOperacao() {
		return this.tipoOperacao;
	}

	public void setTipoOperacao(TipoOperacao tipoOperacao) {
		this.tipoOperacao = tipoOperacao;
	}
	
	@Override
	public String toString() {
		return this.getClass().getSimpleName() + " - " + getNumIdTipoOperObjetoServ();
	}
}