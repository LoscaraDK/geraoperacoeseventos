package br.com.b3.batch.geraoperacoeseventovcp.config.flow;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.job.builder.FlowBuilder;
import org.springframework.batch.core.job.flow.Flow;
import org.springframework.batch.core.job.flow.support.SimpleFlow;
import org.springframework.batch.core.partition.PartitionHandler;
import org.springframework.batch.core.partition.support.TaskExecutorPartitionHandler;
import org.springframework.batch.integration.async.AsyncItemProcessor;
import org.springframework.batch.integration.async.AsyncItemWriter;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.database.JpaPagingItemReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import br.com.b3.batch.geraoperacoeseventovcp.components.CcbVcpD1AmortResgWriter;
import br.com.b3.batch.geraoperacoeseventovcp.config.BatchJob;
import br.com.b3.batch.geraoperacoeseventovcp.config.EventosPartitioner;
import br.com.b3.batch.geraoperacoeseventovcp.listener.EventoStepListener;
import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;
import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpD1AmortResg;
import br.com.b3.batch.geraoperacoeseventovcp.service.EventoService;

@Configuration
public class CcbVcpD1AmortResgFlowConfig {
	private static final String NOME_PROCESSO = "CcbVcpD1AmortResg";
	private static final int CHUNK_SIZE = 1000;
	private static final Logger LOGGER = LoggerFactory.getLogger(BatchJob.class);	
	
	@Autowired
	@StepScope
	private CcbVcpD1AmortResgWriter writer;

	@Autowired
	@StepScope
	@Qualifier(value = "ccbVcpD1AmortResgProcessor")
	private ItemProcessor<VctpgopCcbVcpD1AmortResg, Operacao> converterProcessor;
	
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	
	@Autowired
	@Qualifier("nomeEntityManagerFactory")
	private EntityManagerFactory em;
	
	@Autowired
	@Qualifier("taskExecutor")
	private ThreadPoolTaskExecutor taskExecutor;
	
	@Autowired
	@Qualifier("eventoService")
	private EventoService service;
	
	@Bean(name= "flow" + NOME_PROCESSO )
	public Flow flow() throws Exception{
		return new FlowBuilder<SimpleFlow>("flow" + NOME_PROCESSO)
				.start(masterStep())
				.build();
	}
	
	@Bean (name = "masterStep" + NOME_PROCESSO)
	public Step masterStep() throws Exception{
		return stepBuilderFactory.get("masterStep" + NOME_PROCESSO)
				.partitioner(slaveStep().getName(),partitioner())
				.partitionHandler(handler())
				.build();
	}
	
	@Bean (name = "slaveStep" + NOME_PROCESSO)
	public Step slaveStep() throws Exception{
		return stepBuilderFactory.get("slaveStep" + NOME_PROCESSO)
				.listener(new EventoStepListener())
				.<VctpgopCcbVcpD1AmortResg, Operacao>chunk(CHUNK_SIZE)
				.reader(reader(null, null))
				.processor(processor())
				.writer(writer())
				.build();
	}
	
	@Bean (name = "reader" + NOME_PROCESSO)
	@StepScope
	public JpaPagingItemReader<VctpgopCcbVcpD1AmortResg> reader (
		      @Value("#{stepExecutionContext['minValue']}") Integer minValue,
		      @Value("#{stepExecutionContext['maxValue']}") Integer maxValue) throws Exception{
		
		
		LOGGER.debug(this + " -> minValue -> "+minValue + " to maxValue -> "+maxValue);
		
		JpaPagingItemReader<VctpgopCcbVcpD1AmortResg> readerJPA = new JpaPagingItemReader<VctpgopCcbVcpD1AmortResg>();
		readerJPA.setQueryString("select e from VctpgopCcbVcpD1AmortResg e where e.idView >= :minValue and e.idView <= :maxValue");
		readerJPA.setEntityManagerFactory(em);
		readerJPA.setPageSize(CHUNK_SIZE);
		readerJPA.setSaveState(false);
 
		Map<String, Object> params = new HashMap<>();
		params.put("minValue", new Long(minValue));
		params.put("maxValue", new Long(maxValue));
		readerJPA.setParameterValues(params);
		
		readerJPA.afterPropertiesSet();
		
		return readerJPA;
	}
	
	@Bean (name = "processor" + NOME_PROCESSO)
	public AsyncItemProcessor processor() throws Exception{
		 AsyncItemProcessor<VctpgopCcbVcpD1AmortResg, Operacao> processor = new AsyncItemProcessor<VctpgopCcbVcpD1AmortResg, Operacao>();
		 processor.setDelegate(converterProcessor);
		 processor.setTaskExecutor(taskExecutor);
		 return processor;
	}
	
	@Bean (name = "writer" + NOME_PROCESSO)
	public AsyncItemWriter<Operacao> writer() throws Exception{
		 AsyncItemWriter<Operacao> asyncWriter = new AsyncItemWriter<Operacao>();
		 asyncWriter.setDelegate(writer);
		 return asyncWriter;
	}
	
	@Bean (name = "partitioner" + NOME_PROCESSO)
	public EventosPartitioner partitioner() {
		int totalLinhas = service.countEventosCcbVcpD1AmortResg();
		LOGGER.debug("Total Linhas -> " + totalLinhas);
		
		EventosPartitioner eventosPartitioner = new EventosPartitioner();
		eventosPartitioner.setTotalLinhas(totalLinhas);
		return eventosPartitioner;
	}
	
	@Bean (name = "handler" + NOME_PROCESSO)
	public PartitionHandler handler() throws Exception{
		TaskExecutorPartitionHandler handler = new TaskExecutorPartitionHandler();
		handler.setGridSize(8);
		handler.setTaskExecutor(taskExecutor);
		handler.setStep(slaveStep());
		
		return handler;
	}
}
