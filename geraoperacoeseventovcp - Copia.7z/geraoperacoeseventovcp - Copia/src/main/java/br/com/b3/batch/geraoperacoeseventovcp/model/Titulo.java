package br.com.b3.batch.geraoperacoeseventovcp.model;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


/**
 * The persistent class for the TITULO database table.
 * 
 */
@Entity
@Table(name="TITULO", schema="CETIP")
@NamedQuery(name="Titulo.findAll", query="SELECT t FROM Titulo t")
@PrimaryKeyJoinColumn(name="num_If")
public class Titulo extends InstrumentoFinanceiro {
	private static final long serialVersionUID = 1L;

//	@Id
//	@Column(name="NUM_IF")
//	private long numIf;

	@Column(name="IND_EVENTOS_CURSADOS_CETIP")
	private String indEventosCursadosCetip;

	@Column(name="IND_VENCIDO_INADIMPLIDO")
	private String indVencidoInadimplido;

	@Column(name="NOM_FORMA_TITULO")
	private String nomFormaTitulo;

	@Column(name="NUM_CONTA_AGENTE_PAGAMENTO")
	private BigDecimal numContaAgentePagamento;

	@Column(name="NUM_CONTA_PARTICIPANTE")
	private BigDecimal numContaParticipante;

	@Column(name="NUM_EMISSAO")
	private String numEmissao;

	@Column(name="NUM_ID_CERTIFICADOR")
	private BigDecimal numIdCertificador;

	@Column(name="NUM_ID_ENT_ATU_IND_LIQ_CCP")
	private BigDecimal numIdEntAtuIndLiqCcp;

	@Column(name="NUM_ID_ENTIDADE_CARTORIO")
	private BigDecimal numIdEntidadeCartorio;

	@Column(name="NUM_ID_ENTIDADE_EMIS")
	private BigDecimal numIdEntidadeEmis;

	@Column(name="NUM_ID_ENTIDADE_LIQUID")
	private BigDecimal numIdEntidadeLiquid;

	@Column(name="NUM_ID_LOCAL_NEGOCIACAO")
	private BigDecimal numIdLocalNegociacao;

	@Column(name="NUM_ID_QUALIF_FINALIDADE")
	private BigDecimal numIdQualifFinalidade;

	@Column(name="NUM_ID_TIPO_NEGOCIADOR_SECUND")
	private BigDecimal numIdTipoNegociadorSecund;

	@Column(name="NUM_ID_TIPO_REGIME_TITULO")
	private BigDecimal numIdTipoRegimeTitulo;

	@Column(name="NUM_ID_VEICULO_GARANTIDOR")
	private BigDecimal numIdVeiculoGarantidor;

	@Column(name="QTD_DEPOSITADA")
	private BigDecimal qtdDepositada;

	@Column(name="QTD_EMITIDA")
	private BigDecimal qtdEmitida;

	@Column(name="QTD_RESGATADA")
	private BigDecimal qtdResgatada;

	@Column(name="QTD_RETIRADA")
	private BigDecimal qtdRetirada;

	public Titulo() {
	}

//	public long getNumIf() {
//		return this.numIf;
//	}
//
//	public void setNumIf(long numIf) {
//		this.numIf = numIf;
//	}

	public String getIndEventosCursadosCetip() {
		return this.indEventosCursadosCetip;
	}

	public void setIndEventosCursadosCetip(String indEventosCursadosCetip) {
		this.indEventosCursadosCetip = indEventosCursadosCetip;
	}

	public String getIndVencidoInadimplido() {
		return this.indVencidoInadimplido;
	}

	public void setIndVencidoInadimplido(String indVencidoInadimplido) {
		this.indVencidoInadimplido = indVencidoInadimplido;
	}

	public String getNomFormaTitulo() {
		return this.nomFormaTitulo;
	}

	public void setNomFormaTitulo(String nomFormaTitulo) {
		this.nomFormaTitulo = nomFormaTitulo;
	}

	public BigDecimal getNumContaAgentePagamento() {
		return this.numContaAgentePagamento;
	}

	public void setNumContaAgentePagamento(BigDecimal numContaAgentePagamento) {
		this.numContaAgentePagamento = numContaAgentePagamento;
	}

	public BigDecimal getNumContaParticipante() {
		return this.numContaParticipante;
	}

	public void setNumContaParticipante(BigDecimal numContaParticipante) {
		this.numContaParticipante = numContaParticipante;
	}

	public String getNumEmissao() {
		return this.numEmissao;
	}

	public void setNumEmissao(String numEmissao) {
		this.numEmissao = numEmissao;
	}

	public BigDecimal getNumIdCertificador() {
		return this.numIdCertificador;
	}

	public void setNumIdCertificador(BigDecimal numIdCertificador) {
		this.numIdCertificador = numIdCertificador;
	}

	public BigDecimal getNumIdEntAtuIndLiqCcp() {
		return this.numIdEntAtuIndLiqCcp;
	}

	public void setNumIdEntAtuIndLiqCcp(BigDecimal numIdEntAtuIndLiqCcp) {
		this.numIdEntAtuIndLiqCcp = numIdEntAtuIndLiqCcp;
	}

	public BigDecimal getNumIdEntidadeCartorio() {
		return this.numIdEntidadeCartorio;
	}

	public void setNumIdEntidadeCartorio(BigDecimal numIdEntidadeCartorio) {
		this.numIdEntidadeCartorio = numIdEntidadeCartorio;
	}

	public BigDecimal getNumIdEntidadeEmis() {
		return this.numIdEntidadeEmis;
	}

	public void setNumIdEntidadeEmis(BigDecimal numIdEntidadeEmis) {
		this.numIdEntidadeEmis = numIdEntidadeEmis;
	}

	public BigDecimal getNumIdEntidadeLiquid() {
		return this.numIdEntidadeLiquid;
	}

	public void setNumIdEntidadeLiquid(BigDecimal numIdEntidadeLiquid) {
		this.numIdEntidadeLiquid = numIdEntidadeLiquid;
	}

	public BigDecimal getNumIdLocalNegociacao() {
		return this.numIdLocalNegociacao;
	}

	public void setNumIdLocalNegociacao(BigDecimal numIdLocalNegociacao) {
		this.numIdLocalNegociacao = numIdLocalNegociacao;
	}

	public BigDecimal getNumIdQualifFinalidade() {
		return this.numIdQualifFinalidade;
	}

	public void setNumIdQualifFinalidade(BigDecimal numIdQualifFinalidade) {
		this.numIdQualifFinalidade = numIdQualifFinalidade;
	}

	public BigDecimal getNumIdTipoNegociadorSecund() {
		return this.numIdTipoNegociadorSecund;
	}

	public void setNumIdTipoNegociadorSecund(BigDecimal numIdTipoNegociadorSecund) {
		this.numIdTipoNegociadorSecund = numIdTipoNegociadorSecund;
	}

	public BigDecimal getNumIdTipoRegimeTitulo() {
		return this.numIdTipoRegimeTitulo;
	}

	public void setNumIdTipoRegimeTitulo(BigDecimal numIdTipoRegimeTitulo) {
		this.numIdTipoRegimeTitulo = numIdTipoRegimeTitulo;
	}

	public BigDecimal getNumIdVeiculoGarantidor() {
		return this.numIdVeiculoGarantidor;
	}

	public void setNumIdVeiculoGarantidor(BigDecimal numIdVeiculoGarantidor) {
		this.numIdVeiculoGarantidor = numIdVeiculoGarantidor;
	}

	public BigDecimal getQtdDepositada() {
		return this.qtdDepositada;
	}

	public void setQtdDepositada(BigDecimal qtdDepositada) {
		this.qtdDepositada = qtdDepositada;
	}

	public BigDecimal getQtdEmitida() {
		return this.qtdEmitida;
	}

	public void setQtdEmitida(BigDecimal qtdEmitida) {
		this.qtdEmitida = qtdEmitida;
	}

	public BigDecimal getQtdResgatada() {
		return this.qtdResgatada;
	}

	public void setQtdResgatada(BigDecimal qtdResgatada) {
		this.qtdResgatada = qtdResgatada;
	}

	public BigDecimal getQtdRetirada() {
		return this.qtdRetirada;
	}

	public void setQtdRetirada(BigDecimal qtdRetirada) {
		this.qtdRetirada = qtdRetirada;
	}

}