package br.com.b3.batch.geraoperacoeseventovcp.state;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_AGUARDANDO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.COD_CTL_PROCESSAMENTO_PROCESSADO;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_BT;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_BRUTA_STR;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_CETIP;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.MODALIDADE_SEM;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.PENDENTE_LIQUIDACAO_FINANCEIRA;
import static br.com.b3.batch.geraoperacoeseventovcp.util.Constantes.RETIRADO_POR_SOLICITACAO;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AtuRetiradoEventoState implements OperacaoState{
	private Integer situacaoOperacao;
	private String codCtlProcessamento;
	private static final Logger LOGGER = LoggerFactory.getLogger(AtuRetiradoEventoState.class);
	private static AtuRetiradoEventoState instance = new AtuRetiradoEventoState();
	
	private AtuRetiradoEventoState() {}
	
	public static AtuRetiradoEventoState instance() {
		return instance;
	}
	
	private static final Map<Integer, Integer> map = new HashMap<Integer, Integer>();
	static {
		map.put(MODALIDADE_BRUTA_BT, RETIRADO_POR_SOLICITACAO);
		map.put(MODALIDADE_BRUTA_STR, RETIRADO_POR_SOLICITACAO);
		map.put(MODALIDADE_CETIP, RETIRADO_POR_SOLICITACAO);
		map.put(MODALIDADE_SEM, RETIRADO_POR_SOLICITACAO);
	}
	
	@Override
	public Integer getSituacaoOperacao() {
		return this.situacaoOperacao;
	}
	
	@Override
	public String getCodCtlProcessamento() {
		return this.codCtlProcessamento;
	}
	
	private void setSituacaoOperacao(Integer situacaoOperacao) {
		this.situacaoOperacao = situacaoOperacao;
		
		setCodCtlProcessamento();
	}
	
	private void setCodCtlProcessamento() {
		this.codCtlProcessamento = COD_CTL_PROCESSAMENTO_PROCESSADO;
		if(PENDENTE_LIQUIDACAO_FINANCEIRA.equals(situacaoOperacao)) {
			this.codCtlProcessamento = COD_CTL_PROCESSAMENTO_AGUARDANDO;
		}
	}
	
	@Override
	public void updateState(SituacaoOperacaoContext context) throws Exception {
		if(context.getParameters().eRetiradaPorSolicitacao()) {
			setSituacaoOperacao(map.get(context.getParameters().getModalidade()));
			LOGGER.debug(this + " -> " + context.getCurrent().getSituacaoOperacao() 
					+ " na modalide " + context.getParameters().getModalidade() + " com codCtlProcessamento " + context.getCurrent().getCodCtlProcessamento());
		}else {
			context.setCurrent(EventoAtualizadoState.instance());
			context.next();
		}
	}
}
