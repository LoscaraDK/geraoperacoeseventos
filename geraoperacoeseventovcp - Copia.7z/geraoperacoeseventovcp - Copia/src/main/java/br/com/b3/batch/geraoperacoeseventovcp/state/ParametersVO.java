package br.com.b3.batch.geraoperacoeseventovcp.state;

public class ParametersVO {
	private boolean eContaP1Inativa;
	private boolean eContaP2Inativa;
	private Integer modalidade;
	private Integer numIdEstadoEvento;
	private Integer numTipoEventoLegado;
	private boolean eRetiradaPorSolicitacao;
	
	private ParametersVO(ParametersBuilder builder) {
		this.eContaP1Inativa =  builder.eContaP1Inativa;
		this.eContaP2Inativa =  builder.eContaP2Inativa;
		this.modalidade = builder.modalidade;
		this.numIdEstadoEvento = builder.numIdEstadoEvento;
		this.numTipoEventoLegado = builder.numTipoEventoLegado;
		this.eRetiradaPorSolicitacao = builder.eRetiradaPorSolicitacao; 
	}

	public boolean eContaP1Inativa() {
		return this.eContaP1Inativa;
	}
	public boolean eContaP2Inativa() {
		return this.eContaP2Inativa;
	}
	public Integer getModalidade() {
		return this.modalidade;
	}
	public Integer getEstadoEvento() {
		return this.numIdEstadoEvento;
	}
	public Integer getNumTipoEvento() {
		return this.numTipoEventoLegado;
	}
	public boolean eRetiradaPorSolicitacao() {
		return this.eRetiradaPorSolicitacao;
	}
	
	public static class ParametersBuilder {
		private boolean eContaP1Inativa;
		private boolean eContaP2Inativa;
		private Integer modalidade;
		private Integer numIdEstadoEvento;
		private Integer numTipoEventoLegado;
		private boolean eRetiradaPorSolicitacao;
		
		public ParametersBuilder addContaP1Inativa(boolean eContaP1Inativa) {
			this.eContaP1Inativa = eContaP1Inativa;
			return this;
		}
		public ParametersBuilder addContaP2Inativa(boolean eContaP2Inativa) {
			this.eContaP2Inativa = eContaP2Inativa;
			return this;
		}
		public ParametersBuilder addModalidade(Integer modalidade) {
			this.modalidade = modalidade;
			return this;
		}
		public ParametersBuilder addEstadoEvento(Integer numIdEstadoEvento) {
			this.numIdEstadoEvento = numIdEstadoEvento;
			return this;
		}
		public ParametersBuilder addNumTipoEventoLegado(Integer numTipoEventoLegado) {
			this.numTipoEventoLegado = numTipoEventoLegado;
			return this;
		}
		public ParametersBuilder addRetiradoPorSolicitacao(boolean eRetiradaPorSolicitacao) {
			this.eRetiradaPorSolicitacao = eRetiradaPorSolicitacao;
			return this;
		}
		
		public ParametersVO build() {
			return new ParametersVO(this);
		}
	}
}
