package br.com.b3.batch.geraoperacoeseventovcp.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import br.com.b3.batch.geraoperacoeseventovcp.model.Operacao;

public interface OperacaoRespoitory extends JpaRepository<Operacao, Long> {

}
