package br.com.b3.batch.geraoperacoeseventovcp.modalidade;

public interface ModalidadeStrategy {
	public ModalidadeContext selecionaModalidade(ModalidadeContext context);
	public Integer getModalidadeDetalhada();
}
