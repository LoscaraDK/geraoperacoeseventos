package br.com.b3.batch.geraoperacoeseventovcp.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.b3.batch.geraoperacoeseventovcp.model.VctpgopCcbVcpVenAmortResg;

@Repository
public interface CcbVcpVenAmortResgRepository extends JpaRepository<VctpgopCcbVcpVenAmortResg, Long> {

}


